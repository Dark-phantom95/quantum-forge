/**
 * QUANTUM FORGE AI — Self-contained API handler
 * No external dependencies. All data and logic inline.
 * Deployed as a Vercel serverless function.
 */

// ─── Types ───────────────────────────────────────────────

interface Project {
  id: string;
  name: string;
  tagline: string;
  description: string;
  category: string;
  color: string;
  icon: string;
  features: { icon: string; label: string }[];
  screens: { name: string; description: string }[];
  techStack: { name: string; category: string }[];
  repo: string;
  lastDeployed: string;
  status: 'live' | 'in_review' | 'draft';
  version: string;
  deployments: any[];
  downloads: number;
  rating: number;
}

interface Account {
  id: string;
  name: string;
  handle: string;
  platform: string;
  connected: boolean;
}

interface DeployTask {
  id: string;
  label: string;
  detail: string;
  status: 'pending' | 'active' | 'done';
}

interface DeploymentRecord {
  id: string;
  projectId: string;
  mode: string;
  startTime: number;
  stepDuration: number;
  tasks: DeployTask[];
  project: Project;
}

// ─── In-memory database ─────────────────────────────────

const projects: Project[] = [
  {
    id: 'p1', name: 'FitFlow', tagline: 'AI workout companion',
    description: 'A modern fitness tracking app with AI-generated workout plans, progress analytics, and social challenges.',
    category: 'Health & Fitness', color: 'from-emerald-500 to-teal-600', icon: '💪',
    features: [
      { icon: 'dumbbell', label: 'Workout Plans' }, { icon: 'trending-up', label: 'Progress Tracking' },
      { icon: 'users', label: 'Social Challenges' }, { icon: 'bell', label: 'Smart Reminders' },
    ],
    screens: [
      { name: 'Dashboard', description: 'Daily stats & activity rings' },
      { name: 'Workouts', description: 'Browse & start training sessions' },
      { name: 'Progress', description: 'Charts & achievement history' },
      { name: 'Profile', description: 'Goals & preferences' },
    ],
    techStack: [
      { name: 'React Native', category: 'Framework' }, { name: 'Expo', category: 'Platform' },
      { name: 'Firebase', category: 'Backend' }, { name: 'TypeScript', category: 'Language' },
    ],
    repo: 'quantum-forge/fitflow', lastDeployed: '2 days ago', status: 'live', version: 'v1.2.0',
    downloads: 18420, rating: 4.7,
    deployments: [
      { id: 'd1', version: 'v1.2.0', platform: 'android', status: 'live', date: '2 days ago', downloads: 18420 },
      { id: 'd2', version: 'v1.1.0', platform: 'android', status: 'live', date: '2 weeks ago', downloads: 12100 },
      { id: 'd3', version: 'v1.0.0', platform: 'android', status: 'live', date: '1 month ago', downloads: 8200 },
    ],
  },
  {
    id: 'p2', name: 'MealMuse', tagline: 'Your AI sous chef',
    description: 'Discover recipes based on ingredients you have, plan meals for the week, and generate smart shopping lists.',
    category: 'Food & Drink', color: 'from-orange-500 to-rose-600', icon: '🍳',
    features: [
      { icon: 'search', label: 'Recipe Search' }, { icon: 'calendar', label: 'Meal Planning' },
      { icon: 'shopping-cart', label: 'Shopping Lists' }, { icon: 'heart', label: 'Favorites' },
    ],
    screens: [
      { name: 'Discover', description: 'Trending & suggested recipes' },
      { name: 'Recipe Detail', description: 'Steps, ingredients & timer' },
      { name: 'Meal Plan', description: 'Weekly calendar view' },
      { name: 'Pantry', description: 'Track ingredients on hand' },
    ],
    techStack: [
      { name: 'Flutter', category: 'Framework' }, { name: 'Supabase', category: 'Backend' },
      { name: 'Dart', category: 'Language' }, { name: 'OpenAI API', category: 'AI' },
    ],
    repo: 'quantum-forge/mealmuse', lastDeployed: '5 days ago', status: 'in_review', version: 'v0.9.1',
    downloads: 3200, rating: 4.5,
    deployments: [
      { id: 'd4', version: 'v0.9.1', platform: 'android', status: 'in_review', date: '5 days ago' },
      { id: 'd5', version: 'v0.8.0', platform: 'android', status: 'live', date: '3 weeks ago', downloads: 3200 },
    ],
  },
  {
    id: 'p3', name: 'TaskTide', tagline: 'Tasks that flow with you',
    description: 'A minimalist task manager with natural language input, smart prioritization, and focus mode.',
    category: 'Productivity', color: 'from-violet-500 to-indigo-600', icon: '✅',
    features: [
      { icon: 'check-square', label: 'Smart Tasks' }, { icon: 'zap', label: 'Quick Capture' },
      { icon: 'target', label: 'Focus Mode' }, { icon: 'bar-chart', label: 'Productivity Stats' },
    ],
    screens: [
      { name: 'Today', description: "Today's tasks & priorities" },
      { name: 'Projects', description: 'Organize tasks by project' },
      { name: 'Focus', description: 'Pomodoro timer & deep work' },
      { name: 'Insights', description: 'Weekly productivity trends' },
    ],
    techStack: [
      { name: 'React Native', category: 'Framework' }, { name: 'WatermelonDB', category: 'Database' },
      { name: 'TypeScript', category: 'Language' }, { name: 'OpenAI API', category: 'AI' },
    ],
    repo: 'quantum-forge/tasktide', lastDeployed: '3 weeks ago', status: 'live', version: 'v2.0.1',
    downloads: 9800, rating: 4.8,
    deployments: [
      { id: 'd6', version: 'v2.0.1', platform: 'android', status: 'live', date: '3 weeks ago', downloads: 9800 },
      { id: 'd7', version: 'v1.5.0', platform: 'android', status: 'live', date: '2 months ago', downloads: 6400 },
    ],
  },
  {
    id: 'p4', name: 'Wanderly', tagline: 'Plan trips with AI',
    description: 'Generate personalized travel itineraries, discover hidden gems, and book experiences on the go.',
    category: 'Travel', color: 'from-sky-500 to-blue-600', icon: '✈️',
    features: [
      { icon: 'map', label: 'AI Itineraries' }, { icon: 'compass', label: 'Discover Places' },
      { icon: 'bookmark', label: 'Saved Trips' }, { icon: 'share-2', label: 'Share Plans' },
    ],
    screens: [
      { name: 'Explore', description: 'Destination inspiration' },
      { name: 'Itinerary', description: 'Day-by-day trip plan' },
      { name: 'Map View', description: 'Interactive trip map' },
      { name: 'Trips', description: 'Past & upcoming journeys' },
    ],
    techStack: [
      { name: 'React Native', category: 'Framework' }, { name: 'Firebase', category: 'Backend' },
      { name: 'Mapbox', category: 'Maps' }, { name: 'TypeScript', category: 'Language' },
    ],
    repo: 'quantum-forge/wanderly', lastDeployed: '1 month ago', status: 'draft', version: 'v0.5.0',
    downloads: 0, rating: 0,
    deployments: [
      { id: 'd8', version: 'v0.5.0', platform: 'android', status: 'draft', date: '1 month ago' },
    ],
  },
];

const accounts: Account[] = [
  { id: 'gh', name: 'GitHub', handle: 'quantum-forge', platform: 'github', connected: true },
  { id: 'gp', name: 'Google Play', handle: 'Developer Console', platform: 'googleplay', connected: false },
];

const tokens: Record<string, string> = {};
const deployments: Record<string, DeploymentRecord> = {};

// ─── Helpers ─────────────────────────────────────────────

function cors(res: any) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
}

function json(res: any, data: any, status = 200) {
  res.status(status).json(data);
}

function getBody(req: any): any {
  if (req.body && typeof req.body === 'object') return req.body;
  return {};
}

function getPath(req: any): string {
  let url = req.url || '';
  // Strip query string
  const qIdx = url.indexOf('?');
  if (qIdx >= 0) url = url.slice(0, qIdx);
  // Normalize — ensure it starts with /api
  if (!url.startsWith('/api')) {
    url = '/api' + (url.startsWith('/') ? url : '/' + url);
  }
  return url;
}

function matchRoute(path: string, prefix: string): string | null {
  const regex = new RegExp('^' + prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '/([\\w-]+)$');
  const m = path.match(regex);
  return m ? m[1] : null;
}

function createToken(userId: string): string {
  const token = 'qf_' + userId + '_' + Date.now() + '_' + Math.random().toString(36).slice(2, 10);
  tokens[token] = userId;
  return token;
}

function verifyToken(token: string): string | null {
  return tokens[token] || null;
}

function getUserId(req: any): { userId: string; token: string | null } {
  const auth = req.headers?.authorization || req.headers?.Authorization;
  if (auth && typeof auth === 'string' && auth.startsWith('Bearer ')) {
    const token = auth.slice(7);
    const userId = verifyToken(token);
    if (userId) return { userId, token: null };
  }
  // Auto-login as demo user
  const token = createToken('demo-user');
  return { userId: 'demo-user', token };
}

// ─── Generators ──────────────────────────────────────────

function generateProjectFromIdea(idea: string): Project {
  const lower = idea.toLowerCase();
  let name = 'Nimbus', tagline = 'AI-powered app', category = 'Productivity';
  let color = 'from-blue-500 to-violet-600', icon = '🚀';

  if (lower.includes('shop') || lower.includes('store') || lower.includes('commerce') || lower.includes('cart')) {
    name = 'ShopSphere'; tagline = 'Your store, reinvented'; category = 'Shopping';
    color = 'from-fuchsia-500 to-purple-600'; icon = '🛍️';
  } else if (lower.includes('fit') || lower.includes('workout') || lower.includes('exercise') || lower.includes('gym')) {
    name = 'PulseFit'; tagline = 'Train smarter, not harder'; category = 'Health & Fitness';
    color = 'from-emerald-500 to-teal-600'; icon = '💪';
  } else if (lower.includes('recipe') || lower.includes('food') || lower.includes('cook') || lower.includes('meal')) {
    name = 'Savorly'; tagline = 'Cook with inspiration'; category = 'Food & Drink';
    color = 'from-orange-500 to-rose-600'; icon = '🍳';
  } else if (lower.includes('budget') || lower.includes('finance') || lower.includes('money') || lower.includes('expense')) {
    name = 'CoinWise'; tagline = 'Master your money'; category = 'Finance';
    color = 'from-amber-500 to-yellow-600'; icon = '💰';
  } else if (lower.includes('travel') || lower.includes('trip') || lower.includes('journey')) {
    name = 'Voyagr'; tagline = 'Adventure awaits'; category = 'Travel';
    color = 'from-sky-500 to-cyan-600'; icon = '✈️';
  } else if (lower.includes('meditat') || lower.includes('mindful') || lower.includes('calm') || lower.includes('wellness')) {
    name = 'ZenFlow'; tagline = 'Find your inner peace'; category = 'Health & Fitness';
    color = 'from-teal-500 to-cyan-600'; icon = '🧘';
  } else if (lower.includes('social') || lower.includes('chat') || lower.includes('message') || lower.includes('connect')) {
    name = 'PulseChat'; tagline = 'Connect with everyone'; category = 'Social';
    color = 'from-pink-500 to-rose-600'; icon = '💬';
  } else if (lower.includes('game') || lower.includes('play') || lower.includes('fun')) {
    name = 'PlayForge'; tagline = 'Game on'; category = 'Games';
    color = 'from-purple-500 to-indigo-600'; icon = '🎮';
  }

  return {
    id: 'gen_' + Date.now(), name, tagline, description: idea.trim(), category, color, icon,
    features: [
      { icon: 'zap', label: 'Smart Automation' }, { icon: 'bell', label: 'Push Notifications' },
      { icon: 'shield', label: 'Secure Auth' }, { icon: 'bar-chart', label: 'Analytics Dashboard' },
    ],
    screens: [
      { name: 'Home', description: 'Personalized dashboard & feed' },
      { name: 'Explore', description: 'Browse & discover content' },
      { name: 'Activity', description: 'Recent actions & history' },
      { name: 'Profile', description: 'Account & settings' },
    ],
    techStack: [
      { name: 'React Native', category: 'Framework' }, { name: 'Expo', category: 'Platform' },
      { name: 'Firebase', category: 'Backend' }, { name: 'TypeScript', category: 'Language' },
    ],
    repo: '', lastDeployed: 'Not deployed', status: 'draft', version: 'v1.0.0',
    downloads: 0, rating: 0, deployments: [],
  };
}

function generateProjectFromPackage(pkg: any): Project {
  const formatLabel = (pkg.format || 'apk').toUpperCase();
  return {
    id: 'imp_' + Date.now(), name: pkg.appName || 'Imported App',
    tagline: 'Imported ' + formatLabel + ' package',
    description: 'Imported from ' + pkg.fileName + '. Package ' + pkg.packageName + ', version ' + pkg.versionName + ' (code ' + pkg.versionCode + '). Validated and ready for store deployment.',
    category: 'Imported App', color: 'from-blue-500 to-violet-600', icon: '📦',
    features: [
      { icon: 'package', label: formatLabel + ' Package' },
      { icon: 'shield', label: 'Signature Verified' },
      { icon: 'cpu', label: 'API ' + pkg.minSdk + '+ Compatible' },
      { icon: 'lock', label: pkg.permissions.length + ' Permissions' },
    ],
    screens: [
      { name: 'Main Activity', description: pkg.launchActivity },
      { name: 'Splash', description: 'Cold-start splash screen' },
      { name: 'Settings', description: 'App preferences' },
      { name: 'About', description: 'Version & build info' },
    ],
    techStack: [
      { name: 'Android', category: 'Platform' },
      { name: 'minSdk ' + pkg.minSdk, category: 'API Level' },
      { name: 'targetSdk ' + pkg.targetSdk, category: 'API Level' },
      { name: formatLabel, category: 'Format' },
    ],
    repo: '', lastDeployed: 'Not deployed', status: 'draft', version: 'v' + pkg.versionName,
    downloads: 0, rating: 0, deployments: [],
  };
}

function validatePackage(fileName: string, fileSize: number): any {
  const ACCEPTED = ['apk', 'aab', 'zip'];
  const MAX_BYTES = 150 * 1024 * 1024;
  const ext = fileName.split('.').pop()?.toLowerCase();

  if (!ext || !ACCEPTED.includes(ext)) {
    return { ok: false, error: 'Unsupported file type ".' + (ext || 'unknown') + '". Please upload an APK, AAB, or ZIP file.' };
  }
  if (!fileSize || fileSize === 0) {
    return { ok: false, error: 'The selected file is empty. Please choose a valid package.' };
  }
  if (fileSize > MAX_BYTES) {
    return { ok: false, error: 'File is ' + (fileSize / (1024 * 1024)).toFixed(1) + ' MB — exceeds the 150 MB limit.' };
  }

  // Build package metadata
  const rawBase = fileName.replace(/\.(apk|aab|zip)$/i, '');
  const cleanBase = rawBase.replace(/[-_]+/g, ' ').replace(/\s+/g, ' ').trim() || 'Imported App';
  const appName = cleanBase.split(' ').filter(Boolean)
    .map((w: string) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join(' ');
  const slug = cleanBase.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 14) || 'imported';
  const versionMatch = rawBase.match(/(\d+)\.(\d+)\.(\d+)/);
  const versionName = versionMatch ? versionMatch[0] : '1.0.0';
  const versionCode = versionMatch
    ? parseInt(versionMatch[1]) * 10000 + parseInt(versionMatch[2]) * 100 + parseInt(versionMatch[3]) : 1;
  const hash = rawBase.split('').reduce((a, c) => a + c.charCodeAt(0), 0);
  const SAMPLE_PERMS = [
    'android.permission.INTERNET', 'android.permission.ACCESS_NETWORK_STATE',
    'android.permission.WAKE_LOCK', 'android.permission.POST_NOTIFICATIONS',
    'android.permission.READ_EXTERNAL_STORAGE', 'android.permission.CAMERA',
    'android.permission.VIBRATE', 'android.permission.FOREGROUND_SERVICE',
  ];
  const permissions = SAMPLE_PERMS.slice(0, 3 + (hash % 4));

  return {
    ok: true,
    package: {
      fileName, fileSize, format: ext,
      packageName: 'com.quantumforge.' + slug, appName, versionName, versionCode,
      minSdk: 24 + (hash % 4), targetSdk: 34, permissions,
      sizeMB: fileSize / (1024 * 1024), signature: 'signed',
      architectures: ['arm64-v8a', 'armeabi-v7a', 'x86_64'],
      launchActivity: 'com.quantumforge.' + slug + '.MainActivity',
    },
  };
}

function startDeployment(project: Project, mode: string): DeploymentRecord {
  const baseTasks: DeployTask[] = mode === 'import'
    ? [
        { id: 'validate', label: 'Validating package', detail: 'Re-checking signed bundle integrity', status: 'pending' },
        { id: 'repo', label: 'Syncing repository', detail: 'Pushing source to GitHub', status: 'pending' },
        { id: 'version', label: 'Creating release', detail: 'Tagging version from manifest', status: 'pending' },
        { id: 'store', label: 'Submitting to Play Store', detail: 'Uploading bundle to Google Play', status: 'pending' },
        { id: 'live', label: 'Going live', detail: 'Activating production release', status: 'pending' },
      ]
    : [
        { id: 'build', label: 'Compiling build', detail: 'Bundling production assets', status: 'pending' },
        { id: 'repo', label: 'Syncing repository', detail: 'Pushing to GitHub', status: 'pending' },
        { id: 'version', label: 'Creating release', detail: 'Tagging version v1.0.0', status: 'pending' },
        { id: 'store', label: 'Submitting to Play Store', detail: 'Uploading AAB to Google Play', status: 'pending' },
        { id: 'live', label: 'Going live', detail: 'Activating production release', status: 'pending' },
      ];

  const record: DeploymentRecord = {
    id: 'dep_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8),
    projectId: project.id, mode, startTime: Date.now(), stepDuration: 1700,
    tasks: baseTasks, project,
  };
  deployments[record.id] = record;
  return record;
}

function getDeploymentStatus(id: string): any {
  const record = deployments[id];
  if (!record) return null;
  const elapsed = Date.now() - record.startTime;
  const completedSteps = Math.min(Math.floor(elapsed / record.stepDuration), record.tasks.length);
  const tasks = record.tasks.map((task, i) => ({
    ...task,
    status: i < completedSteps ? 'done' : i === completedSteps && completedSteps < record.tasks.length ? 'active' : 'pending',
  }));
  const doneCount = tasks.filter((t: any) => t.status === 'done').length;
  return { tasks, progress: (doneCount / tasks.length) * 100, complete: doneCount === tasks.length, project: record.project };
}

// ─── Main handler ───────────────────────────────────────

export default function handler(req: any, res: any) {
  cors(res);
  if (req.method === 'OPTIONS') return res.status(200).end();

  const path = getPath(req);
  const method = req.method || 'GET';
  const body = getBody(req);

  try {
    const { userId, token } = getUserId(req);
    const authMeta = token ? { token } : {};

    // ── Health ──────────────────────────────────────
    if (path === '/api/health' && method === 'GET') {
      return json(res, { status: 'ok', service: 'QUANTUM FORGE AI API', version: '1.0.0', timestamp: new Date().toISOString(), ...authMeta });
    }

    // ── Auth ────────────────────────────────────────
    if (path === '/api/auth/login' && method === 'POST') {
      const t = createToken(userId);
      return json(res, { token: t, user: { id: userId, name: 'Developer', email: 'dev@quantumforge.ai', plan: 'Pro' } });
    }
    if (path === '/api/auth/me' && method === 'GET') {
      return json(res, { user: { id: userId, name: 'Developer', email: 'dev@quantumforge.ai', plan: 'Pro' }, ...authMeta });
    }

    // ── Projects ────────────────────────────────────
    if (path === '/api/projects' && method === 'GET') {
      return json(res, { projects, ...authMeta });
    }
    if (path === '/api/projects' && method === 'POST') {
      const p: Project = {
        id: 'usr_' + Date.now(), name: body.name || 'Untitled App', tagline: body.tagline || '',
        description: body.description || '', category: body.category || 'Productivity',
        color: body.color || 'from-blue-500 to-violet-600', icon: body.icon || '🚀',
        features: body.features || [], screens: body.screens || [], techStack: body.techStack || [],
        repo: body.repo || '', lastDeployed: 'Not deployed', status: 'draft',
        version: body.version || 'v1.0.0', downloads: 0, rating: 0, deployments: [],
      };
      projects.unshift(p);
      return json(res, { project: p, ...authMeta }, 201);
    }

    const projectId = matchRoute(path, '/api/projects');
    if (projectId) {
      if (method === 'GET') {
        const p = projects.find((x) => x.id === projectId);
        return p ? json(res, { project: p, ...authMeta }) : json(res, { error: 'Project not found' }, 404);
      }
      if (method === 'PUT') {
        const idx = projects.findIndex((x) => x.id === projectId);
        if (idx === -1) return json(res, { error: 'Project not found' }, 404);
        projects[idx] = { ...projects[idx], ...body };
        return json(res, { project: projects[idx], ...authMeta });
      }
      if (method === 'DELETE') {
        const idx = projects.findIndex((x) => x.id === projectId);
        if (idx === -1) return json(res, { error: 'Project not found' }, 404);
        projects.splice(idx, 1);
        return json(res, { success: true, ...authMeta });
      }
    }

    // ── Generate ────────────────────────────────────
    if (path === '/api/generate' && method === 'POST') {
      const { idea } = body;
      if (!idea || idea.trim().length < 5) return json(res, { error: 'Please provide a longer description' }, 400);
      const p = generateProjectFromIdea(idea);
      projects.unshift(p);
      return json(res, { project: p, ...authMeta }, 201);
    }

    // ── Import ──────────────────────────────────────
    if (path === '/api/import/validate' && method === 'POST') {
      const { fileName, fileSize } = body;
      if (!fileName) return json(res, { error: 'fileName is required' }, 400);
      if (typeof fileSize !== 'number') return json(res, { error: 'fileSize must be a number' }, 400);
      const result = validatePackage(fileName, fileSize);
      return json(res, { ...result, ...authMeta });
    }
    if (path === '/api/import/extract' && method === 'POST') {
      const pkg = body;
      if (!pkg || !pkg.appName) return json(res, { error: 'Invalid package data' }, 400);
      const p = generateProjectFromPackage(pkg);
      projects.unshift(p);
      return json(res, { project: p, ...authMeta }, 201);
    }

    // ── Accounts ───────────────────────────────────
    if (path === '/api/accounts' && method === 'GET') {
      return json(res, { accounts, ...authMeta });
    }
    const accountPlatform = matchRoute(path, '/api/accounts');
    if (accountPlatform && method === 'PUT') {
      const acc = accounts.find((a) => a.platform === accountPlatform || a.id === accountPlatform);
      if (!acc) return json(res, { error: 'Account not found' }, 404);
      acc.connected = !acc.connected;
      return json(res, { account: acc, ...authMeta });
    }

    // ── Deploy ──────────────────────────────────────
    if (path === '/api/deploy' && method === 'POST') {
      const { project, mode } = body;
      if (!project) return json(res, { error: 'Project not found' }, 404);
      const dep = startDeployment(project, mode || 'generate');
      return json(res, { deployment: { id: dep.id }, ...authMeta }, 201);
    }
    const deployStatusMatch = path.match(/^\/api\/deploy\/([\w-]+)\/status$/);
    if (deployStatusMatch && method === 'GET') {
      const status = getDeploymentStatus(deployStatusMatch[1]);
      return status ? json(res, { ...status, ...authMeta }) : json(res, { error: 'Deployment not found' }, 404);
    }

    // ── Stats ───────────────────────────────────────
    if (path === '/api/stats' && method === 'GET') {
      const liveApps = projects.filter((p) => p.status === 'live').length;
      const totalDownloads = projects.reduce((s, p) => s + p.downloads, 0);
      const rated = projects.filter((p) => p.rating > 0);
      const avgRating = rated.length > 0 ? parseFloat((rated.reduce((s, p) => s + p.rating, 0) / rated.length).toFixed(1)) : 0;
      return json(res, { stats: { liveApps, totalDownloads, avgRating, totalProjects: projects.length }, ...authMeta });
    }

    // ── 404 ─────────────────────────────────────────
    return json(res, { error: 'Route not found: ' + method + ' ' + path }, 404);
  } catch (err: any) {
    return json(res, { error: err.message || 'Internal server error' }, 500);
  }
}
