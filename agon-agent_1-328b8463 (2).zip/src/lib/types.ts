export type Tab = 'home' | 'projects' | 'settings';

export type FlowStep =
  | 'idea'
  | 'generating'
  | 'details'
  | 'preview'
  | 'connect'
  | 'deploy'
  | 'success'
  | 'import'
  | 'importing'
  | 'import-details';

export type DeployMode = 'generate' | 'import';

export type PackageFormat = 'apk' | 'aab' | 'zip';

export interface ProjectFeature {
  icon: string;
  label: string;
}

export interface ProjectScreen {
  name: string;
  description: string;
}

export interface TechItem {
  name: string;
  category: string;
}

export interface Deployment {
  id: string;
  version: string;
  platform: 'android' | 'ios' | 'web';
  status: 'live' | 'in_review' | 'draft' | 'failed';
  date: string;
  downloads?: number;
}

export interface Project {
  id: string;
  name: string;
  tagline: string;
  description: string;
  category: string;
  color: string;
  icon: string;
  features: ProjectFeature[];
  screens: ProjectScreen[];
  techStack: TechItem[];
  repo: string;
  lastDeployed: string;
  status: 'live' | 'in_review' | 'draft';
  version: string;
  deployments: Deployment[];
  downloads: number;
  rating: number;
}

export interface GenerationStep {
  id: string;
  label: string;
  detail: string;
  icon: string;
}

export interface DeployTask {
  id: string;
  label: string;
  detail: string;
  status: 'pending' | 'active' | 'done' | 'error';
}

export interface ConnectedAccount {
  id: string;
  name: string;
  handle: string;
  platform: 'github' | 'googleplay';
  connected: boolean;
  avatar?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'ai';
  text: string;
}

/** Metadata extracted from an imported Android package (APK / AAB / ZIP). */
export interface ImportedPackage {
  fileName: string;
  fileSize: number; // bytes
  format: PackageFormat;
  packageName: string;
  appName: string;
  versionName: string;
  versionCode: number;
  minSdk: number;
  targetSdk: number;
  permissions: string[];
  sizeMB: number;
  signature: 'signed' | 'unsigned' | 'debug';
  architectures: string[];
  launchActivity: string;
}

export interface ImportValidationStep {
  id: string;
  label: string;
  detail: string;
  icon: string;
}

/** Result of validating an uploaded package file. */
export interface ImportValidationResult {
  ok: boolean;
  error?: string;
  package?: ImportedPackage;
}
