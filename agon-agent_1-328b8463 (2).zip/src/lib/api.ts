/**
 * Frontend API client for QUANTUM FORGE AI.
 * All calls fall back to local data when the backend is unavailable,
 * so the app works seamlessly with or without the API.
 */

import {
  projects as localProjects,
  generateProjectFromIdea,
  validatePackageFile,
  generateProjectFromPackage,
} from './data';
import type { Project, ImportedPackage, ImportValidationResult } from './types';

const API_BASE = '/api';
const TOKEN_KEY = 'qf_token';

function getToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

function setToken(token: string): void {
  try {
    localStorage.setItem(TOKEN_KEY, token);
  } catch {
    /* ignore */
  }
}

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const token = getToken();
  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options?.headers,
    },
  });
  if (!res.ok) throw new Error(`API ${res.status}`);
  const data = await res.json();
  if (data.token) setToken(data.token);
  return data as T;
}

/** Try an API call; if it fails, return the fallback value. */
async function withFallback<T>(apiCall: () => Promise<T>, fallback: T): Promise<T> {
  try {
    return await apiCall();
  } catch {
    return fallback;
  }
}

export interface AccountInfo {
  id: string;
  name: string;
  handle: string;
  platform: string;
  connected: boolean;
}

export const api = {
  /** Check if the backend API is reachable. */
  async checkHealth(): Promise<boolean> {
    try {
      await request('/health');
      return true;
    } catch {
      return false;
    }
  },

  /** Fetch all projects from the API (falls back to local seed data). */
  async getProjects(): Promise<Project[]> {
    return withFallback(
      async () => {
        const res = await request<{ projects: Project[] }>('/projects');
        return res.projects?.length ? res.projects : localProjects;
      },
      localProjects
    );
  },

  /** Generate a project from a natural-language idea via the API. */
  async generateProject(idea: string): Promise<Project> {
    return withFallback(
      async () => {
        const res = await request<{ project: Project }>('/generate', {
          method: 'POST',
          body: JSON.stringify({ idea }),
        });
        return res.project;
      },
      generateProjectFromIdea(idea)
    );
  },

  /** Validate an imported package file via the API. */
  async validatePackage(
    fileName: string,
    fileSize: number
  ): Promise<ImportValidationResult> {
    return withFallback(
      async () => {
        return await request<ImportValidationResult>('/import/validate', {
          method: 'POST',
          body: JSON.stringify({ fileName, fileSize }),
        });
      },
      validatePackageFile({ name: fileName, size: fileSize } as File)
    );
  },

  /** Extract a project from an imported package via the API. */
  async extractPackage(pkg: ImportedPackage): Promise<Project> {
    return withFallback(
      async () => {
        const res = await request<{ project: Project }>('/import/extract', {
          method: 'POST',
          body: JSON.stringify(pkg),
        });
        return res.project;
      },
      generateProjectFromPackage(pkg)
    );
  },

  /** Fetch connected accounts from the API. */
  async getAccounts(): Promise<AccountInfo[] | null> {
    return withFallback(
      async () => {
        const res = await request<{ accounts: AccountInfo[] }>('/accounts');
        return res.accounts;
      },
      null
    );
  },

  /** Toggle an account connection via the API (fire-and-forget). */
  async toggleAccount(platform: string): Promise<void> {
    try {
      await request(`/accounts/${platform}`, { method: 'PUT' });
    } catch {
      /* local state already updated */
    }
  },

  /** Start a deployment via the API. */
  async startDeployment(
    project: Project,
    mode: string
  ): Promise<{ id: string } | null> {
    return withFallback(
      async () => {
        const res = await request<{ deployment: { id: string } }>('/deploy', {
          method: 'POST',
          body: JSON.stringify({ project, mode }),
        });
        return res.deployment;
      },
      null
    );
  },

  /** Poll deployment status from the API. */
  async getDeploymentStatus(id: string): Promise<any | null> {
    return withFallback(
      () => request<any>(`/deploy/${id}/status`),
      null
    );
  },

  /** Fetch dashboard stats from the API. */
  async getStats(): Promise<any | null> {
    return withFallback(() => request('/stats'), null);
  },
};
