import {
  createContext,
  useContext,
  useState,
  useCallback,
  useEffect,
  useRef,
  type ReactNode,
} from 'react';
import type { Tab, FlowStep, Project, DeployMode, ImportedPackage } from './types';
import {
  generateProjectFromIdea,
  generateProjectFromPackage,
  projects as localProjects,
} from './data';
import { api } from './api';

interface AppState {
  activeTab: Tab;
  flowStep: FlowStep | null;
  idea: string;
  generatedProject: Project | null;
  selectedProjectId: string | null;
  githubConnected: boolean;
  playConnected: boolean;
  importedPackage: ImportedPackage | null;
  deployMode: DeployMode;
  projects: Project[];
  apiReady: boolean;
  setTab: (tab: Tab) => void;
  startCreate: () => void;
  startImport: () => void;
  setIdea: (idea: string) => void;
  setFlowStep: (step: FlowStep) => void;
  generateProject: () => void;
  setImportedPackage: (pkg: ImportedPackage | null) => void;
  finalizeImport: () => void;
  selectProject: (id: string | null) => void;
  toggleGithub: () => void;
  togglePlay: () => void;
  resetFlow: () => void;
  exitFlow: () => void;
}

const Ctx = createContext<AppState | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [activeTab, setActiveTab] = useState<Tab>('home');
  const [flowStep, setFlowStepState] = useState<FlowStep | null>(null);
  const [idea, setIdea] = useState('');
  const [generatedProject, setGeneratedProject] = useState<Project | null>(null);
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);
  const [githubConnected, setGithubConnected] = useState(true);
  const [playConnected, setPlayConnected] = useState(false);
  const [importedPackage, setImportedPackage] = useState<ImportedPackage | null>(null);
  const [deployMode, setDeployMode] = useState<DeployMode>('generate');
  const [projects, setProjects] = useState<Project[]>(localProjects);
  const [apiReady, setApiReady] = useState(false);

  const generatedRef = useRef(false);

  // ─── Init: check API health and sync data on mount ──────────────────
  useEffect(() => {
    let cancelled = false;

    (async () => {
      const ready = await api.checkHealth();
      if (cancelled) return;
      setApiReady(ready);

      if (ready) {
        // Fetch projects and accounts in parallel
        const [projectsData, accountsData] = await Promise.all([
          api.getProjects(),
          api.getAccounts(),
        ]);
        if (cancelled) return;
        if (projectsData?.length) setProjects(projectsData);
        if (accountsData) {
          const gh = accountsData.find((a) => a.platform === 'github');
          const gp = accountsData.find((a) => a.platform === 'googleplay');
          if (gh) setGithubConnected(gh.connected);
          if (gp) setPlayConnected(gp.connected);
        }
      }
    })();

    return () => {
      cancelled = true;
    };
  }, []);

  const setFlowStep = useCallback((step: FlowStep) => {
    setFlowStepState(step);
  }, []);

  const startCreate = useCallback(() => {
    generatedRef.current = false;
    setDeployMode('generate');
    setFlowStepState('idea');
  }, []);

  const startImport = useCallback(() => {
    setDeployMode('import');
    setImportedPackage(null);
    setGeneratedProject(null);
    setFlowStepState('import');
  }, []);

  const setTab = useCallback((tab: Tab) => {
    setActiveTab(tab);
  }, []);

  // ─── Generate: set locally immediately, sync with API in background ──
  const generateProject = useCallback(() => {
    if (generatedRef.current) return;
    generatedRef.current = true;

    // Immediately set from local generator so the UI never stalls
    const local = generateProjectFromIdea(idea);
    setGeneratedProject(local);

    // Sync with API in the background — updates if the API returns different data
    api.generateProject(idea).then((apiProject) => {
      setGeneratedProject(apiProject);
    }).catch(() => {
      /* local fallback already set */
    });
  }, [idea]);

  // ─── Finalize import: set locally immediately, sync with API ─────────
  const finalizeImport = useCallback(() => {
    if (!importedPackage) return;

    // Immediately set from local generator
    const local = generateProjectFromPackage(importedPackage);
    setGeneratedProject(local);
    setFlowStepState('import-details');

    // Sync with API in the background
    api.extractPackage(importedPackage).then((apiProject) => {
      setGeneratedProject(apiProject);
    }).catch(() => {
      /* local fallback already set */
    });
  }, [importedPackage]);

  const selectProject = useCallback((id: string | null) => {
    setSelectedProjectId(id);
  }, []);

  // ─── Account toggles: update local state, sync with API ─────────────
  const toggleGithub = useCallback(() => {
    setGithubConnected((v) => !v);
    api.toggleAccount('github');
  }, []);

  const togglePlay = useCallback(() => {
    setPlayConnected((v) => !v);
    api.toggleAccount('googleplay');
  }, []);

  const resetFlow = useCallback(() => {
    setIdea('');
    setGeneratedProject(null);
    setImportedPackage(null);
    generatedRef.current = false;
    setFlowStepState('idea');
  }, []);

  const exitFlow = useCallback(() => {
    setFlowStepState(null);
    setIdea('');
    setGeneratedProject(null);
    setImportedPackage(null);
    generatedRef.current = false;
  }, []);

  return (
    <Ctx.Provider
      value={{
        activeTab,
        flowStep,
        idea,
        generatedProject,
        selectedProjectId,
        githubConnected,
        playConnected,
        importedPackage,
        deployMode,
        projects,
        apiReady,
        setTab,
        startCreate,
        startImport,
        setIdea,
        setFlowStep,
        generateProject,
        setImportedPackage,
        finalizeImport,
        selectProject,
        toggleGithub,
        togglePlay,
        resetFlow,
        exitFlow,
      }}
    >
      {children}
    </Ctx.Provider>
  );
}

export function useApp() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
