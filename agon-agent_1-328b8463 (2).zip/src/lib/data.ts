import type {
  Project,
  GenerationStep,
  DeployTask,
  ConnectedAccount,
  ImportValidationStep,
  ImportedPackage,
  ImportValidationResult,
  PackageFormat,
} from './types';

export const examplePrompts = [
  {
    emoji: '🛍️',
    title: 'E-commerce Store',
    prompt: 'A modern shopping app with product catalog, cart, and checkout',
  },
  {
    emoji: '💪',
    title: 'Fitness Tracker',
    prompt: 'A workout tracker with exercise logs, progress charts, and goals',
  },
  {
    emoji: '🍳',
    title: 'Recipe Finder',
    prompt: 'A recipe app with search, favorites, and meal planning',
  },
  {
    emoji: '💰',
    title: 'Budget Manager',
    prompt: 'A personal finance app with expense tracking and budget alerts',
  },
];

export const generationSteps: GenerationStep[] = [
  {
    id: 'analyze',
    label: 'Analyzing your idea',
    detail: 'Understanding requirements & intent',
    icon: 'brain',
  },
  {
    id: 'architecture',
    label: 'Designing architecture',
    detail: 'Selecting optimal tech stack',
    icon: 'layers',
  },
  {
    id: 'screens',
    label: 'Generating screens',
    detail: 'Crafting UI layouts & components',
    icon: 'layout',
  },
  {
    id: 'logic',
    label: 'Writing app logic',
    detail: 'Building features & data models',
    icon: 'code',
  },
  {
    id: 'polish',
    label: 'Polishing & optimizing',
    detail: 'Animations, theming & performance',
    icon: 'sparkles',
  },
];

export const deployTasks: DeployTask[] = [
  {
    id: 'build',
    label: 'Compiling build',
    detail: 'Bundling production assets',
    status: 'pending',
  },
  {
    id: 'repo',
    label: 'Syncing repository',
    detail: 'Pushing to GitHub',
    status: 'pending',
  },
  {
    id: 'version',
    label: 'Creating release',
    detail: 'Tagging version v1.0.0',
    status: 'pending',
  },
  {
    id: 'store',
    label: 'Submitting to Play Store',
    detail: 'Uploading AAB to Google Play',
    status: 'pending',
  },
  {
    id: 'live',
    label: 'Going live',
    detail: 'Activating production release',
    status: 'pending',
  },
];

export const connectedAccounts: ConnectedAccount[] = [
  {
    id: 'gh',
    name: 'GitHub',
    handle: 'quantum-forge',
    platform: 'github',
    connected: true,
  },
  {
    id: 'gp',
    name: 'Google Play',
    handle: 'Developer Console',
    platform: 'googleplay',
    connected: false,
  },
];

export const projects: Project[] = [
  {
    id: 'p1',
    name: 'FitFlow',
    tagline: 'AI workout companion',
    description:
      'A modern fitness tracking app with AI-generated workout plans, progress analytics, and social challenges.',
    category: 'Health & Fitness',
    color: 'from-emerald-500 to-teal-600',
    icon: '💪',
    features: [
      { icon: 'dumbbell', label: 'Workout Plans' },
      { icon: 'trending-up', label: 'Progress Tracking' },
      { icon: 'users', label: 'Social Challenges' },
      { icon: 'bell', label: 'Smart Reminders' },
    ],
    screens: [
      { name: 'Dashboard', description: 'Daily stats & activity rings' },
      { name: 'Workouts', description: 'Browse & start training sessions' },
      { name: 'Progress', description: 'Charts & achievement history' },
      { name: 'Profile', description: 'Goals & preferences' },
    ],
    techStack: [
      { name: 'React Native', category: 'Framework' },
      { name: 'Expo', category: 'Platform' },
      { name: 'Firebase', category: 'Backend' },
      { name: 'TypeScript', category: 'Language' },
    ],
    repo: 'quantum-forge/fitflow',
    lastDeployed: '2 days ago',
    status: 'live',
    version: 'v1.2.0',
    downloads: 18420,
    rating: 4.7,
    deployments: [
      { id: 'd1', version: 'v1.2.0', platform: 'android', status: 'live', date: '2 days ago', downloads: 18420 },
      { id: 'd2', version: 'v1.1.0', platform: 'android', status: 'live', date: '2 weeks ago', downloads: 12100 },
      { id: 'd3', version: 'v1.0.0', platform: 'android', status: 'live', date: '1 month ago', downloads: 8200 },
    ],
  },
  {
    id: 'p2',
    name: 'MealMuse',
    tagline: 'Your AI sous chef',
    description:
      'Discover recipes based on ingredients you have, plan meals for the week, and generate smart shopping lists.',
    category: 'Food & Drink',
    color: 'from-orange-500 to-rose-600',
    icon: '🍳',
    features: [
      { icon: 'search', label: 'Recipe Search' },
      { icon: 'calendar', label: 'Meal Planning' },
      { icon: 'shopping-cart', label: 'Shopping Lists' },
      { icon: 'heart', label: 'Favorites' },
    ],
    screens: [
      { name: 'Discover', description: 'Trending & suggested recipes' },
      { name: 'Recipe Detail', description: 'Steps, ingredients & timer' },
      { name: 'Meal Plan', description: 'Weekly calendar view' },
      { name: 'Pantry', description: 'Track ingredients on hand' },
    ],
    techStack: [
      { name: 'Flutter', category: 'Framework' },
      { name: 'Supabase', category: 'Backend' },
      { name: 'Dart', category: 'Language' },
      { name: 'OpenAI API', category: 'AI' },
    ],
    repo: 'quantum-forge/mealmuse',
    lastDeployed: '5 days ago',
    status: 'in_review',
    version: 'v0.9.1',
    downloads: 3200,
    rating: 4.5,
    deployments: [
      { id: 'd4', version: 'v0.9.1', platform: 'android', status: 'in_review', date: '5 days ago' },
      { id: 'd5', version: 'v0.8.0', platform: 'android', status: 'live', date: '3 weeks ago', downloads: 3200 },
    ],
  },
  {
    id: 'p3',
    name: 'TaskTide',
    tagline: 'Tasks that flow with you',
    description:
      'A minimalist task manager with natural language input, smart prioritization, and focus mode.',
    category: 'Productivity',
    color: 'from-violet-500 to-indigo-600',
    icon: '✅',
    features: [
      { icon: 'check-square', label: 'Smart Tasks' },
      { icon: 'zap', label: 'Quick Capture' },
      { icon: 'target', label: 'Focus Mode' },
      { icon: 'bar-chart', label: 'Productivity Stats' },
    ],
    screens: [
      { name: 'Today', description: 'Today\'s tasks & priorities' },
      { name: 'Projects', description: 'Organize tasks by project' },
      { name: 'Focus', description: 'Pomodoro timer & deep work' },
      { name: 'Insights', description: 'Weekly productivity trends' },
    ],
    techStack: [
      { name: 'React Native', category: 'Framework' },
      { name: 'WatermelonDB', category: 'Database' },
      { name: 'TypeScript', category: 'Language' },
      { name: 'OpenAI API', category: 'AI' },
    ],
    repo: 'quantum-forge/tasktide',
    lastDeployed: '3 weeks ago',
    status: 'live',
    version: 'v2.0.1',
    downloads: 9800,
    rating: 4.8,
    deployments: [
      { id: 'd6', version: 'v2.0.1', platform: 'android', status: 'live', date: '3 weeks ago', downloads: 9800 },
      { id: 'd7', version: 'v1.5.0', platform: 'android', status: 'live', date: '2 months ago', downloads: 6400 },
    ],
  },
  {
    id: 'p4',
    name: 'Wanderly',
    tagline: 'Plan trips with AI',
    description:
      'Generate personalized travel itineraries, discover hidden gems, and book experiences on the go.',
    category: 'Travel',
    color: 'from-sky-500 to-blue-600',
    icon: '✈️',
    features: [
      { icon: 'map', label: 'AI Itineraries' },
      { icon: 'compass', label: 'Discover Places' },
      { icon: 'bookmark', label: 'Saved Trips' },
      { icon: 'share-2', label: 'Share Plans' },
    ],
    screens: [
      { name: 'Explore', description: 'Destination inspiration' },
      { name: 'Itinerary', description: 'Day-by-day trip plan' },
      { name: 'Map View', description: 'Interactive trip map' },
      { name: 'Trips', description: 'Past & upcoming journeys' },
    ],
    techStack: [
      { name: 'React Native', category: 'Framework' },
      { name: 'Firebase', category: 'Backend' },
      { name: 'Mapbox', category: 'Maps' },
      { name: 'TypeScript', category: 'Language' },
    ],
    repo: 'quantum-forge/wanderly',
    lastDeployed: '1 month ago',
    status: 'draft',
    version: 'v0.5.0',
    downloads: 0,
    rating: 0,
    deployments: [
      { id: 'd8', version: 'v0.5.0', platform: 'android', status: 'draft', date: '1 month ago' },
    ],
  },
];

export function generateProjectFromIdea(idea: string): Project {
  const lower = idea.toLowerCase();
  let name = 'Nimbus';
  let tagline = 'AI-powered app';
  let category = 'Productivity';
  let color = 'from-blue-500 to-violet-600';
  let icon = '🚀';

  if (lower.includes('shop') || lower.includes('store') || lower.includes('commerce') || lower.includes('cart')) {
    name = 'ShopSphere';
    tagline = 'Your store, reinvented';
    category = 'Shopping';
    color = 'from-fuchsia-500 to-purple-600';
    icon = '🛍️';
  } else if (lower.includes('fit') || lower.includes('workout') || lower.includes('exercise') || lower.includes('gym')) {
    name = 'PulseFit';
    tagline = 'Train smarter, not harder';
    category = 'Health & Fitness';
    color = 'from-emerald-500 to-teal-600';
    icon = '💪';
  } else if (lower.includes('recipe') || lower.includes('food') || lower.includes('cook') || lower.includes('meal')) {
    name = 'Savorly';
    tagline = 'Cook with inspiration';
    category = 'Food & Drink';
    color = 'from-orange-500 to-rose-600';
    icon = '🍳';
  } else if (lower.includes('budget') || lower.includes('finance') || lower.includes('money') || lower.includes('expense')) {
    name = 'CoinWise';
    tagline = 'Master your money';
    category = 'Finance';
    color = 'from-amber-500 to-yellow-600';
    icon = '💰';
  } else if (lower.includes('travel') || lower.includes('trip') || lower.includes('journey')) {
    name = 'Voyagr';
    tagline = 'Adventure awaits';
    category = 'Travel';
    color = 'from-sky-500 to-cyan-600';
    icon = '✈️';
  }

  return {
    id: 'new',
    name,
    tagline,
    description: idea.trim(),
    category,
    color,
    icon,
    features: [
      { icon: 'zap', label: 'Smart Automation' },
      { icon: 'bell', label: 'Push Notifications' },
      { icon: 'shield', label: 'Secure Auth' },
      { icon: 'bar-chart', label: 'Analytics Dashboard' },
    ],
    screens: [
      { name: 'Home', description: 'Personalized dashboard & feed' },
      { name: 'Explore', description: 'Browse & discover content' },
      { name: 'Activity', description: 'Recent actions & history' },
      { name: 'Profile', description: 'Account & settings' },
    ],
    techStack: [
      { name: 'React Native', category: 'Framework' },
      { name: 'Expo', category: 'Platform' },
      { name: 'Firebase', category: 'Backend' },
      { name: 'TypeScript', category: 'Language' },
    ],
    repo: '',
    lastDeployed: 'Not deployed',
    status: 'draft',
    version: 'v1.0.0',
    downloads: 0,
    rating: 0,
    deployments: [],
  };
}

/* ---------------------------------------------------------------------------
 * Import flow — APK / AAB / ZIP package validation & extraction
 * ------------------------------------------------------------------------- */

export const importValidationSteps: ImportValidationStep[] = [
  {
    id: 'integrity',
    label: 'Verifying file integrity',
    detail: 'Checking package structure & checksums',
    icon: 'shield-check',
  },
  {
    id: 'manifest',
    label: 'Extracting manifest',
    detail: 'Parsing AndroidManifest.xml',
    icon: 'file-code',
  },
  {
    id: 'compat',
    label: 'Compatibility check',
    detail: 'Validating SDK & architecture support',
    icon: 'cpu',
  },
  {
    id: 'security',
    label: 'Security scan',
    detail: 'Auditing permissions & signature',
    icon: 'lock',
  },
  {
    id: 'prepare',
    label: 'Preparing package',
    detail: 'Normalizing for store deployment',
    icon: 'package',
  },
];

/** Deploy tasks used when publishing an imported package (no build step). */
export const importDeployTasks: DeployTask[] = [
  {
    id: 'validate',
    label: 'Validating package',
    detail: 'Re-checking signed bundle integrity',
    status: 'pending',
  },
  {
    id: 'repo',
    label: 'Syncing repository',
    detail: 'Pushing source to GitHub',
    status: 'pending',
  },
  {
    id: 'version',
    label: 'Creating release',
    detail: 'Tagging version from manifest',
    status: 'pending',
  },
  {
    id: 'store',
    label: 'Submitting to Play Store',
    detail: 'Uploading bundle to Google Play',
    status: 'pending',
  },
  {
    id: 'live',
    label: 'Going live',
    detail: 'Activating production release',
    status: 'pending',
  },
];

export const ACCEPTED_EXTENSIONS: PackageFormat[] = ['apk', 'aab', 'zip'];
export const MAX_PACKAGE_BYTES = 150 * 1024 * 1024; // 150 MB

const SAMPLE_PERMISSIONS = [
  'android.permission.INTERNET',
  'android.permission.ACCESS_NETWORK_STATE',
  'android.permission.WAKE_LOCK',
  'android.permission.POST_NOTIFICATIONS',
  'android.permission.READ_EXTERNAL_STORAGE',
  'android.permission.CAMERA',
  'android.permission.VIBRATE',
  'android.permission.FOREGROUND_SERVICE',
];

/**
 * Validates a real browser File object: checks extension, size, and that it is
 * non-empty. Returns a parsed ImportedPackage on success or a descriptive error.
 */
export function validatePackageFile(file: File): ImportValidationResult {
  const ext = file.name.split('.').pop()?.toLowerCase() as PackageFormat | undefined;

  if (!ext || !ACCEPTED_EXTENSIONS.includes(ext)) {
    return {
      ok: false,
      error: `Unsupported file type ".${ext || 'unknown'}". Please upload an APK, AAB, or ZIP file.`,
    };
  }

  if (file.size === 0) {
    return {
      ok: false,
      error: 'The selected file is empty. Please choose a valid package.',
    };
  }

  if (file.size > MAX_PACKAGE_BYTES) {
    const mb = (file.size / (1024 * 1024)).toFixed(1);
    return {
      ok: false,
      error: `File is ${mb} MB — exceeds the 150 MB limit. Please upload a smaller package.`,
    };
  }

  return { ok: true, package: buildPackageFromFile(file, ext) };
}

/**
 * Builds plausible, deterministic package metadata from a real uploaded file.
 * Derives app name, package id, and version from the filename so the extracted
 * details always feel relevant to what the user actually uploaded.
 */
export function buildPackageFromFile(file: File, format: PackageFormat): ImportedPackage {
  const rawBase = file.name.replace(/\.(apk|aab|zip)$/i, '');
  const cleanBase = rawBase.replace(/[-_]+/g, ' ').replace(/\s+/g, ' ').trim() || 'Imported App';
  const appName = cleanBase
    .split(' ')
    .filter(Boolean)
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
    .join(' ');

  const slug = cleanBase.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 14) || 'imported';

  // Deterministic pseudo-version from filename so it stays stable per file.
  const versionMatch = rawBase.match(/(\d+)\.(\d+)\.(\d+)/);
  const versionName = versionMatch ? versionMatch[0] : '1.0.0';
  const versionCode = versionMatch
    ? parseInt(versionMatch[1]) * 10000 + parseInt(versionMatch[2]) * 100 + parseInt(versionMatch[3])
    : 1;

  // Deterministic permission subset based on filename hash.
  const hash = rawBase.split('').reduce((a, c) => a + c.charCodeAt(0), 0);
  const permCount = 3 + (hash % 4);
  const permissions = SAMPLE_PERMISSIONS.slice(0, permCount);

  const sizeMB = file.size / (1024 * 1024);

  return {
    fileName: file.name,
    fileSize: file.size,
    format,
    packageName: `com.quantumforge.${slug}`,
    appName,
    versionName,
    versionCode,
    minSdk: 24 + (hash % 4), // Android 7.0+
    targetSdk: 34,
    permissions,
    sizeMB,
    signature: 'signed',
    architectures: ['arm64-v8a', 'armeabi-v7a', 'x86_64'],
    launchActivity: `com.quantumforge.${slug}.MainActivity`,
  };
}

/** Maps an imported package into a Project so it flows through deploy/success. */
export function generateProjectFromPackage(pkg: ImportedPackage): Project {
  const formatLabel = pkg.format.toUpperCase();
  return {
    id: 'imported',
    name: pkg.appName,
    tagline: `Imported ${formatLabel} package`,
    description: `Imported from ${pkg.fileName}. Package ${pkg.packageName}, version ${pkg.versionName} (code ${pkg.versionCode}). Validated and ready for store deployment.`,
    category: 'Imported App',
    color: 'from-blue-500 to-violet-600',
    icon: '📦',
    features: [
      { icon: 'package', label: `${formatLabel} Package` },
      { icon: 'shield', label: 'Signature Verified' },
      { icon: 'cpu', label: `API ${pkg.minSdk}+ Compatible` },
      { icon: 'lock', label: `${pkg.permissions.length} Permissions` },
    ],
    screens: [
      { name: 'Main Activity', description: pkg.launchActivity },
      { name: 'Splash', description: 'Cold-start splash screen' },
      { name: 'Settings', description: 'App preferences' },
      { name: 'About', description: 'Version & build info' },
    ],
    techStack: [
      { name: 'Android', category: 'Platform' },
      { name: `minSdk ${pkg.minSdk}`, category: 'API Level' },
      { name: `targetSdk ${pkg.targetSdk}`, category: 'API Level' },
      { name: formatLabel, category: 'Format' },
    ],
    repo: '',
    lastDeployed: 'Not deployed',
    status: 'draft',
    version: `v${pkg.versionName}`,
    downloads: 0,
    rating: 0,
    deployments: [],
  };
}
