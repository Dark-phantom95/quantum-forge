import type { ReactNode } from 'react';
import { Signal, Wifi, BatteryFull } from 'lucide-react';

export function PhoneFrame({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen w-full items-center justify-center bg-[#05050a] p-0 sm:p-6">
      {/* Ambient background glow for desktop */}
      <div className="pointer-events-none fixed inset-0 hidden sm:block">
        <div className="absolute left-1/4 top-1/4 h-96 w-96 -translate-x-1/2 rounded-full bg-blue-600/10 blur-[120px]" />
        <div className="absolute right-1/4 bottom-1/4 h-96 w-96 translate-x-1/2 rounded-full bg-violet-600/10 blur-[120px]" />
      </div>

      <div className="relative z-10 h-screen w-full max-w-[420px] overflow-hidden bg-[#0a0a12] sm:h-[860px] sm:rounded-[2.75rem] sm:border sm:border-white/10 sm:shadow-2xl sm:shadow-black/50">
        {/* Notch */}
        <div className="pointer-events-none absolute left-1/2 top-0 z-50 hidden h-7 w-36 -translate-x-1/2 rounded-b-2xl bg-black sm:block" />

        {/* Status bar */}
        <div className="flex items-center justify-between px-7 pt-3 pb-1 text-white sm:pt-4">
          <span className="text-[13px] font-semibold tracking-tight">9:41</span>
          <div className="flex items-center gap-1.5">
            <Signal size={14} className="text-white/90" />
            <Wifi size={14} className="text-white/90" />
            <BatteryFull size={18} className="text-white/90" />
          </div>
        </div>

        {/* Content area */}
        <div className="relative h-[calc(100%-36px)] overflow-hidden">{children}</div>
      </div>
    </div>
  );
}
