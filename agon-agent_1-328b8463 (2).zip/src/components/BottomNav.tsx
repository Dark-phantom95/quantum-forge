import { motion } from 'framer-motion';
import { Home, FolderGit2, Settings, Sparkles } from 'lucide-react';
import { useApp } from '../lib/store';
import type { Tab } from '../lib/types';

const tabs: { id: Tab; label: string; icon: typeof Home }[] = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'projects', label: 'Projects', icon: FolderGit2 },
];

export function BottomNav() {
  const { activeTab, setTab, startCreate } = useApp();

  return (
    <div className="absolute bottom-0 left-0 right-0 z-40">
      <div className="relative flex items-end justify-around border-t border-white/[0.06] bg-[#0a0a12]/90 px-6 pb-6 pt-3 backdrop-blur-2xl">
        {tabs.map((tab) => {
          const Icon = tab.icon;
 const active = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setTab(tab.id)}
              className="flex flex-col items-center gap-1 px-4"
            >
              <Icon
                size={22}
                className={active ? 'text-blue-400' : 'text-white/40'}
              />
              <span
                className={`text-[10px] font-medium ${active ? 'text-blue-400' : 'text-white/40'}`}
              >
                {tab.label}
              </span>
            </button>
          );
        })
        }

        {/* Center create button */}
        <div className="absolute left-1/2 -top-5 -translate-x-1/2">
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={startCreate}
            className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-500 to-violet-600 shadow-lg shadow-violet-600/40 ring-4 ring-[#0a0a12]"
          >
            <Sparkles size={24} className="text-white" />
          </motion.button>
        </div>

        <button
          onClick={() => setTab('settings')}
          className="flex flex-col items-center gap-1 px-4"
        >
          <Settings
            size={22}
            className={activeTab === 'settings' ? 'text-blue-400' : 'text-white/40'}
          />
          <span
            className={`text-[10px] font-medium ${activeTab === 'settings' ? 'text-blue-400' : 'text-white/40'}`}
          >
            Settings
          </span>
        </button>
      </div>
    </div>
  );
}
