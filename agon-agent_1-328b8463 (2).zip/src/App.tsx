import { AnimatePresence, motion } from 'framer-motion';
import { AppProvider, useApp } from './lib/store';
import { PhoneFrame } from './components/PhoneFrame';
import { BottomNav } from './components/BottomNav';
import { HomeScreen } from './screens/HomeScreen';
import { CreateScreen } from './screens/CreateScreen';
import { GenerationScreen } from './screens/GenerationScreen';
import { ProjectDetailsScreen } from './screens/ProjectDetailsScreen';
import { PreviewScreen } from './screens/PreviewScreen';
import { ConnectScreen } from './screens/ConnectScreen';
import { DeployScreen } from './screens/DeployScreen';
import { SuccessScreen } from './screens/SuccessScreen';
import { ProjectsScreen } from './screens/ProjectsScreen';
import { SettingsScreen } from './screens/SettingsScreen';
import { ImportScreen } from './screens/ImportScreen';
import { ImportingScreen } from './screens/ImportingScreen';
import { ImportDetailsScreen } from './screens/ImportDetailsScreen';

function FlowRouter() {
  const { flowStep } = useApp();

  const screenMap: Record<string, React.ReactNode> = {
    idea: <CreateScreen />,
    generating: <GenerationScreen />,
    details: <ProjectDetailsScreen />,
    preview: <PreviewScreen />,
    connect: <ConnectScreen />,
    deploy: <DeployScreen />,
    success: <SuccessScreen />,
    import: <ImportScreen />,
    importing: <ImportingScreen />,
    'import-details': <ImportDetailsScreen />,
  };

  if (!flowStep) return null;

  return (
    <div className="absolute inset-0 z-50 bg-[#0a0a12]">
      <AnimatePresence mode="wait">
        <motion.div
          key={flowStep}
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -30 }}
          transition={{ duration: 0.25, ease: 'easeOut' }}
          className="h-full"
        >
          {screenMap[flowStep]}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

function TabRouter() {
  const { activeTab } = useApp();

  return (
    <div className="h-full">
      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="h-full"
        >
          {activeTab === 'home' && <HomeScreen />}
          {activeTab === 'projects' && <ProjectsScreen />}
          {activeTab === 'settings' && <SettingsScreen />}
        </motion.div>
      </AnimatePresence>
      <BottomNav />
    </div>
  );
}

function AppInner() {
  const { flowStep } = useApp();

  return (
    <PhoneFrame>
      <div className="relative h-full">
        <TabRouter />
        <FlowRouter />
      </div>
    </PhoneFrame>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppInner />
    </AppProvider>
  );
}
