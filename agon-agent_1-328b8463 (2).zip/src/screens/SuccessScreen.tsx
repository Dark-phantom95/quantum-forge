import { motion } from 'framer-motion';
import { Check, Download, Star, GitBranch, ExternalLink, Home, Rocket, Package } from 'lucide-react';
import { useApp } from '../lib/store';
import { Card, PrimaryButton, GhostButton, GlowOrb, Pill } from '../components/ui';

export function SuccessScreen() {
  const { generatedProject, deployMode, importedPackage, exitFlow, setTab } = useApp();
  if (!generatedProject) return null;
  const p = generatedProject;
  const isImport = deployMode === 'import';

  return (
    <div className="relative flex h-full flex-col items-center overflow-y-auto px-6 pb-6 pt-8">
      <GlowOrb className="-top-10 left-1/2 h-56 w-56 -translate-x-1/2 bg-emerald-500/20" />
      <GlowOrb className="top-20 -right-10 h-40 w-40 bg-blue-600/15" />

      {/* Confetti dots */}
      {[...Array(12)].map((_, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, y: -20, x: 0 }}
          animate={{
            opacity: [0, 1, 0],
            y: [0, 300 + Math.random() * 200],
            x: (Math.random() - 0.5) * 200,
            rotate: Math.random() * 360,
          }}
          transition={{ duration: 2 + Math.random(), delay: Math.random() * 0.5, repeat: Infinity, repeatDelay: 1 }}
          className={`absolute top-0 h-2 w-2 rounded-sm ${
            ['bg-blue-400', 'bg-violet-400', 'bg-emerald-400', 'bg-amber-400', 'bg-pink-400'][i % 5]
          }`}
        />
      ))}

      {/* Success badge */}
      <motion.div
        initial={{ scale: 0, rotate: -180 }}
        animate={{ scale: 1, rotate: 0 }}
        transition={{ type: 'spring', stiffness: 200, damping: 15 }}
        className="relative z-10 mb-6 flex h-24 w-24 items-center justify-center rounded-full bg-gradient-to-br from-emerald-400 to-teal-600 shadow-2xl shadow-emerald-500/40"
      >
        <motion.div
          animate={{ scale: [1, 1.15, 1] }}
          transition={{ duration: 1.5, repeat: Infinity }}
          className="absolute inset-0 rounded-full bg-emerald-400/30 blur-xl"
        />
        <Check size={48} className="relative text-white" strokeWidth={3} />
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
        <Pill className="bg-emerald-500/15 text-emerald-400">
          {isImport ? <Package size={11} /> : <Rocket size={11} />} Deployed Successfully
        </Pill>
        <h1 className="mt-3 text-center text-2xl font-bold text-white">{p.name} is live! 🎉</h1>
        <p className="mt-1.5 max-w-[280px] text-center text-sm text-white/50">
          {isImport
            ? 'Your imported package has been published to Google Play and synced to GitHub.'
            : 'Your app has been published to Google Play and synced to GitHub.'}
        </p>
      </motion.div>

      {/* App card */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="mt-6 w-full max-w-[320px]">
        <Card className="flex items-center gap-3 p-4">
          <div className={`flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br ${p.color} text-2xl`}>
            {p.icon}
          </div>
          <div className="flex-1">
            <p className="text-sm font-bold text-white">{p.name}</p>
            <p className="text-[11px] text-white/40">
              {isImport && importedPackage
                ? `${importedPackage.format.toUpperCase()} · ${importedPackage.sizeMB.toFixed(1)} MB · ${p.version}`
                : `${p.category} · ${p.version}`}
            </p>
            <div className="mt-1 flex items-center gap-2 text-[10px] text-white/50">
              <span className="flex items-center gap-0.5 text-amber-400">
                <Star size={10} className="fill-amber-400" /> New
              </span>
              <span className="flex items-center gap-0.5 text-emerald-400">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" /> Live
              </span>
            </div>
          </div>
        </Card>
      </motion.div>

      {/* Deployment info */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="mt-3 w-full max-w-[320px] space-y-2">
        <div className="grid grid-cols-2 gap-2">
          <Card className="p-3">
            <GitBranch size={16} className="mb-1 text-blue-400" />
            <p className="text-[10px] text-white/40">Repository</p>
            <p className="truncate text-[11px] font-semibold text-white">quantum-forge/{p.name.toLowerCase().replace(/\s+/g, '')}</p>
          </Card>
          <Card className="p-3">
            <Download size={16} className="mb-1 text-violet-400" />
            <p className="text-[10px] text-white/40">Play Store</p>
            <p className="text-[11px] font-semibold text-white">In production</p>
          </Card>
        </div>
      </motion.div>

      {/* Actions — BUG FIX: exitFlow no longer overrides the tab, so setTab
          ('projects') is respected and the user lands on Projects. */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }} className="mt-6 w-full max-w-[320px] space-y-3">
        <PrimaryButton onClick={() => { setTab('projects'); exitFlow(); }}>
          <ExternalLink size={16} /> View in Projects
        </PrimaryButton>
        <GhostButton onClick={() => { setTab('home'); exitFlow(); }}>
          <Home size={16} /> Back to Home
        </GhostButton>
      </motion.div>
    </div>
  );
}
