import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Github,
  Play,
  Bell,
  Moon,
  Shield,
  HelpCircle,
  ChevronRight,
  LogOut,
  CreditCard,
  Globe,
  Zap,
  Check,
} from 'lucide-react';
import { useApp } from '../lib/store';
import { Card, ScreenHeader, GlowOrb, Pill } from '../components/ui';

export function SettingsScreen() {
  const { githubConnected, playConnected, toggleGithub, togglePlay, apiReady } = useApp();
  const [notifications, setNotifications] = useState(true);
  const [autoDeploy, setAutoDeploy] = useState(false);

  return (
    <div className="h-full overflow-y-auto pb-28">
      <GlowOrb className="-top-10 -left-10 h-40 w-40 bg-blue-600/15" />
      <ScreenHeader title="Settings" subtitle="Manage your account & preferences" />

      <div className="px-5">
        {/* Profile card */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
          <Card className="flex items-center gap-4 p-4">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-blue-500 to-violet-600 shadow-lg shadow-violet-600/30">
              <Zap size={28} className="text-white" />
            </div>
            <div className="flex-1">
              <p className="text-base font-bold text-white">Developer Account</p>
              <p className="text-xs text-white/40">dev@quantumforge.ai</p>
              <Pill className="mt-1.5 bg-gradient-to-r from-blue-500/20 to-violet-500/20 text-blue-300">
                <Zap size={10} /> Pro Plan
              </Pill>
            </div>
          </Card>
        </motion.div>

        {/* API status */}
        <Card className="mt-3 flex items-center gap-3 p-3.5">
          <div className={`flex h-9 w-9 items-center justify-center rounded-xl ${apiReady ? 'bg-emerald-500/15' : 'bg-white/5'}`}>
            <div className={`h-2.5 w-2.5 rounded-full ${apiReady ? 'bg-emerald-400 animate-pulse' : 'bg-white/30'}`} />
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium text-white">Backend API</p>
            <p className="text-[11px] text-white/40">{apiReady ? 'Connected · Real-time sync active' : 'Offline mode · Using local data'}</p>
          </div>
          <span className={`rounded-full px-2.5 py-1 text-[10px] font-medium ${apiReady ? 'bg-emerald-500/15 text-emerald-400' : 'bg-white/10 text-white/50'}`}>
            {apiReady ? 'Online' : 'Offline'}
          </span>
        </Card>

        {/* Connected accounts */}
        <h3 className="mb-3 mt-6 text-xs font-semibold uppercase tracking-wider text-white/40">
          Connected Accounts
        </h3>
        <Card className="divide-y divide-white/[0.04]">
          <AccountRow
            icon={Github}
            name="GitHub"
            handle={githubConnected ? 'quantum-forge · 42 repos' : 'Not connected'}
            connected={githubConnected}
            onToggle={toggleGithub}
          />
          <AccountRow
            icon={Play}
            name="Google Play"
            handle={playConnected ? 'Developer Console' : 'Not connected'}
            connected={playConnected}
            onToggle={togglePlay}
            iconBg="bg-gradient-to-br from-green-500 to-emerald-600"
          />
        </Card>

        {/* Preferences */}
        <h3 className="mb-3 mt-6 text-xs font-semibold uppercase tracking-wider text-white/40">
          Preferences
        </h3>
        <Card className="divide-y divide-white/[0.04]">
          <ToggleRow
            icon={Bell}
            label="Push Notifications"
            desc="Build & deploy alerts"
            value={notifications}
            onChange={() => setNotifications((v) => !v)}
          />
          <ToggleRow
            icon={Zap}
            label="Auto-deploy on sync"
            desc="Deploy when repo updates"
            value={autoDeploy}
            onChange={() => setAutoDeploy((v) => !v)}
          />
          <NavRow icon={Moon} label="Appearance" value="Dark" />
          <NavRow icon={Globe} label="Language" value="English" />
        </Card>

        {/* Account */}
        <h3 className="mb-3 mt-6 text-xs font-semibold uppercase tracking-wider text-white/40">
          Account
        </h3>
        <Card className="divide-y divide-white/[0.04]">
          <NavRow icon={CreditCard} label="Billing & Subscription" value="Pro · $19/mo" />
          <NavRow icon={Shield} label="Privacy & Security" />
          <NavRow icon={HelpCircle} label="Help & Support" />
        </Card>

        {/* Logout */}
        <button className="mt-6 flex w-full items-center justify-center gap-2 rounded-2xl border border-rose-500/20 bg-rose-500/5 py-3.5 text-sm font-semibold text-rose-400 transition hover:bg-rose-500/10 active:scale-95">
          <LogOut size={16} /> Sign Out
        </button>

        <p className="mt-4 text-center text-[11px] text-white/30">QUANTUM FORGE AI v2.4.0 · Build 2024</p>
      </div>
    </div>
  );
}

function AccountRow({
  icon: Icon,
  name,
  handle,
  connected,
  onToggle,
  iconBg = 'bg-white/5',
}: {
  icon: typeof Github;
  name: string;
  handle: string;
  connected: boolean;
  onToggle: () => void;
  iconBg?: string;
}) {
  return (
    <div className="flex items-center gap-3 p-3.5">
      <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${iconBg}`}>
        <Icon size={18} className={iconBg === 'bg-white/5' ? 'text-white' : 'text-white'} />
      </div>
      <div className="flex-1">
        <p className="text-sm font-medium text-white">{name}</p>
        <p className="text-[11px] text-white/40">{handle}</p>
      </div>
      <button
        onClick={onToggle}
        className={`rounded-full px-3 py-1.5 text-[11px] font-semibold transition ${
          connected
            ? 'bg-emerald-500/15 text-emerald-400'
            : 'border border-white/10 bg-white/5 text-white/70 hover:bg-white/10'
        }`}
      >
        {connected ? 'Connected' : 'Connect'}
      </button>
    </div>
  );
}

function ToggleRow({
  icon: Icon,
  label,
  desc,
  value,
  onChange,
}: {
  icon: typeof Bell;
  label: string;
  desc: string;
  value: boolean;
  onChange: () => void;
}) {
  return (
    <div className="flex items-center gap-3 p-3.5">
      <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-white/5">
        <Icon size={16} className="text-white/60" />
      </div>
      <div className="flex-1">
        <p className="text-sm font-medium text-white">{label}</p>
        <p className="text-[11px] text-white/40">{desc}</p>
      </div>
      <button
        onClick={onChange}
        className={`relative h-6 w-11 rounded-full transition ${value ? 'bg-blue-500' : 'bg-white/10'}`}
      >
        <motion.span
          animate={{ x: value ? 22 : 2 }}
          className="absolute top-0.5 h-5 w-5 rounded-full bg-white shadow-md"
        />
      </button>
    </div>
  );
}

function NavRow({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof Bell;
  label: string;
  value?: string;
}) {
  return (
    <button className="flex w-full items-center gap-3 p-3.5 text-left transition hover:bg-white/[0.02]">
      <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-white/5">
        <Icon size={16} className="text-white/60" />
      </div>
      <span className="flex-1 text-sm font-medium text-white">{label}</span>
      {value && <span className="text-xs text-white/40">{value}</span>}
      <ChevronRight size={16} className="text-white/30" />
    </button>
  );
}
