import { motion } from 'framer-motion';
import { Sparkles, TrendingUp, Download, Star, ArrowRight, Zap, GitBranch, Smartphone, Package } from 'lucide-react';
import { useApp } from '../lib/store';
import { Card, SectionTitle, GlowOrb } from '../components/ui';

export function HomeScreen() {
  const { startCreate, startImport, setTab, projects } = useApp();
  const liveCount = projects.filter((p) => p.status === 'live').length;
  const totalDownloads = projects.reduce((s, p) => s + p.downloads, 0);

  return (
    <div className="h-full overflow-y-auto pb-28">
      <GlowOrb className="-top-20 -right-10 h-48 w-48 bg-blue-600/20" />
      <GlowOrb className="top-40 -left-16 h-48 w-48 bg-violet-600/20" />

      {/* Greeting */}
      <div className="relative px-5 pt-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-white/50">Welcome back</p>
            <h1 className="text-2xl font-bold text-white">Let's build something</h1>
          </div>
          <div className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br from-blue-500 to-violet-600 shadow-lg shadow-violet-600/30">
            <Sparkles size={20} className="text-white" />
          </div>
        </div>
      </div>

      {/* Hero CTA */}
      <div className="px-5 pt-5">
        <motion.button
          whileTap={{ scale: 0.98 }}
          onClick={startCreate}
          className="relative w-full overflow-hidden rounded-3xl bg-gradient-to-br from-blue-600 via-blue-600 to-violet-700 p-5 text-left shadow-xl shadow-blue-600/30"
        >
          <div className="absolute -right-6 -top-6 h-28 w-28 rounded-full bg-white/10 blur-xl" />
          <div className="relative">
            <div className="mb-3 inline-flex items-center gap-1.5 rounded-full bg-white/15 px-3 py-1 text-[11px] font-semibold text-white">
              <Sparkles size={12} /> AI BUILD MODE
            </div>
            <p className="text-xl font-bold leading-tight text-white">
              Describe it.<br />We build & deploy it.
            </p>
            <p className="mt-1.5 text-sm text-blue-100/80">
              From idea to live app in minutes
            </p>
            <div className="mt-4 inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2.5 text-sm font-semibold text-blue-700">
              Start building <ArrowRight size={16} />
            </div>
          </div>
        </motion.button>
      </div>

      {/* Stats */}
      <div className="px-5 pt-5">
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: 'Live Apps', value: liveCount, icon: Smartphone, color: 'text-emerald-400' },
            { label: 'Downloads', value: `${(totalDownloads / 1000).toFixed(1)}k`, icon: Download, color: 'text-blue-400' },
            { label: 'Avg Rating', value: '4.6', icon: Star, color: 'text-amber-400' },
          ].map((s) => (
            <Card key={s.label} className="p-3 text-center">
              <s.icon size={18} className={`mx-auto mb-1.5 ${s.color}`} />
              <p className="text-lg font-bold text-white">{s.value}</p>
              <p className="text-[10px] text-white/40">{s.label}</p>
            </Card>
          ))}
        </div>
      </div>

      {/* Quick actions */}
      <SectionTitle>Quick Actions</SectionTitle>
      <div className="px-5 space-y-3">
        {[
          { icon: Zap, label: 'New from idea', desc: 'Describe an app in your words', action: startCreate, color: 'from-blue-500 to-cyan-500' },
          { icon: Package, label: 'Import package', desc: 'Upload APK, AAB, or ZIP to deploy', action: startImport, color: 'from-violet-500 to-fuchsia-500' },
          { icon: GitBranch, label: 'Sync repositories', desc: 'Pull latest from GitHub', action: () => setTab('projects'), color: 'from-emerald-500 to-teal-500' },
          { icon: TrendingUp, label: 'View analytics', desc: 'Track downloads & ratings', action: () => setTab('projects'), color: 'from-amber-500 to-orange-500' },
        ].map((a) => (
          <Card key={a.label} onClick={a.action} className="flex items-center gap-3 p-3.5">
            <div className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br ${a.color}`}>
              <a.icon size={20} className="text-white" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-semibold text-white">{a.label}</p>
              <p className="text-xs text-white/40">{a.desc}</p>
            </div>
            <ArrowRight size={18} className="text-white/30" />
          </Card>
        ))}
      </div>

      {/* Recent projects */}
      <SectionTitle>Recent Projects</SectionTitle>
      <div className="px-5 space-y-3">
        {projects.slice(0, 2).map((p) => (
          <Card key={p.id} onClick={() => setTab('projects')} className="flex items-center gap-3 p-3.5">
            <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br ${p.color} text-2xl`}>
              {p.icon}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <p className="text-sm font-semibold text-white">{p.name}</p>
                <StatusBadge status={p.status} />
              </div>
              <p className="truncate text-xs text-white/40">{p.tagline} • {p.version}</p>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; cls: string }> = {
    live: { label: 'Live', cls: 'bg-emerald-500/15 text-emerald-400' },
    in_review: { label: 'In Review', cls: 'bg-amber-500/15 text-amber-400' },
    draft: { label: 'Draft', cls: 'bg-white/10 text-white/50' },
  };
  const s = map[status] || map.draft;
  return <span className={`rounded-full px-2 py-0.5 text-[10px] font-medium ${s.cls}`}>{s.label}</span>;
}
