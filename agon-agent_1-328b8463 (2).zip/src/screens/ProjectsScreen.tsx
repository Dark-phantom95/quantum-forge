import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Search,
  GitBranch,
  Star,
  Download,
  ChevronRight,
  ArrowLeft,
  History,
  Smartphone,
  Globe,
  RefreshCw,
  Eye,
  Filter,
} from 'lucide-react';
import { useApp } from '../lib/store';
import type { Project } from '../lib/types';
import { Card, ScreenHeader, StatusDot, GlowOrb, Pill } from '../components/ui';

const statusLabels: Record<string, string> = {
  live: 'Live',
  in_review: 'In Review',
  draft: 'Draft',
};

export function ProjectsScreen() {
  const { startCreate, startImport, projects: allProjects } = useApp();
  const [selected, setSelected] = useState<Project | null>(null);
  const [filter, setFilter] = useState<'all' | 'live' | 'in_review' | 'draft'>('all');

  const filtered = filter === 'all' ? allProjects : allProjects.filter((p) => p.status === filter);

  if (selected) {
    return <ProjectDetail project={selected} onBack={() => setSelected(null)} />;
  }

  return (
    <div className="h-full overflow-y-auto pb-28">
      <GlowOrb className="-top-10 -right-10 h-40 w-40 bg-violet-600/15" />
      <ScreenHeader title="Projects" subtitle={`${allProjects.length} apps in your workspace`} />

      {/* Search */}
      <div className="px-5">
        <div className="flex h-11 items-center gap-2 rounded-2xl border border-white/[0.06] bg-white/[0.03] px-3.5">
          <Search size={16} className="text-white/40" />
          <input
            placeholder="Search projects..."
            className="flex-1 bg-transparent text-sm text-white placeholder:text-white/30 outline-none"
          />
          <Filter size={16} className="text-white/30" />
        </div>
      </div>

      {/* Filter chips */}
      <div className="flex gap-2 overflow-x-auto px-5 py-4 scrollbar-hide">
        {([
          { id: 'all', label: 'All' },
          { id: 'live', label: 'Live' },
          { id: 'in_review', label: 'In Review' },
          { id: 'draft', label: 'Draft' },
        ] as const).map((f) => (
          <button
            key={f.id}
            onClick={() => setFilter(f.id)}
            className={`shrink-0 rounded-full px-3.5 py-1.5 text-xs font-medium transition ${
              filter === f.id ? 'bg-blue-500 text-white' : 'bg-white/5 text-white/50'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Project list */}
      <div className="space-y-3 px-5">
        <AnimatePresence>
          {filtered.map((p, i) => (
            <motion.div
              key={p.id}
              layout
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
            >
              <Card onClick={() => setSelected(p)} className="p-4">
                <div className="flex items-start gap-3">
                  <div className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br ${p.color} text-2xl`}>
                    {p.icon}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <p className="truncate text-sm font-bold text-white">{p.name}</p>
                      <Pill
                        className={
                          p.status === 'live'
                            ? 'bg-emerald-500/15 text-emerald-400'
                            : p.status === 'in_review'
                            ? 'bg-amber-500/15 text-amber-400'
                            : 'bg-white/10 text-white/50'
                        }
                      >
                        <StatusDot status={p.status} /> {statusLabels[p.status]}
                      </Pill>
                    </div>
                    <p className="truncate text-xs text-white/40">{p.tagline}</p>
                    <div className="mt-2 flex items-center gap-3 text-[11px] text-white/40">
                      <span className="flex items-center gap-1">
                        <GitBranch size={11} className="text-blue-400" /> {p.repo}
                      </span>
                      <span className="flex items-center gap-1">
                        <Download size={11} className="text-violet-400" /> {p.downloads > 0 ? `${p.downloads.toLocaleString()}` : '—'}
                      </span>
                      {p.rating > 0 && (
                        <span className="flex items-center gap-1">
                          <Star size={11} className="fill-amber-400 text-amber-400" /> {p.rating}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="mt-3 flex items-center justify-between border-t border-white/[0.04] pt-3">
                  <span className="text-[11px] text-white/30">{p.version} · {p.lastDeployed}</span>
                  <ChevronRight size={16} className="text-white/30" />
                </div>
              </Card>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* New project CTA */}
      <div className="px-5 pt-4 space-y-3">
        <button
          onClick={startCreate}
          className="w-full rounded-2xl border-2 border-dashed border-white/10 py-4 text-sm font-medium text-white/50 transition hover:border-blue-500/40 hover:text-blue-400"
        >
          + Start a new project
        </button>
        <button
          onClick={startImport}
          className="w-full rounded-2xl border-2 border-dashed border-white/10 py-4 text-sm font-medium text-white/50 transition hover:border-violet-500/40 hover:text-violet-400"
        >
          + Import existing package
        </button>
      </div>
    </div>
  );
}

function ProjectDetail({ project, onBack }: { project: Project; onBack: () => void }) {
  return (
    <div className="h-full overflow-y-auto pb-6">
      <GlowOrb className="-top-10 right-0 h-40 w-40 bg-blue-600/15" />
      <ScreenHeader title={project.name} subtitle={project.tagline} onBack={onBack} />

      <div className="px-5">
        {/* Banner */}
        <div className={`relative overflow-hidden rounded-3xl bg-gradient-to-br ${project.color} p-5`}>
          <div className="absolute -right-4 -top-4 h-24 w-24 rounded-full bg-white/15 blur-xl" />
          <div className="relative flex items-center gap-4">
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-white/20 text-4xl backdrop-blur-sm">
              {project.icon}
            </div>
            <div className="flex-1">
              <h2 className="text-xl font-bold text-white">{project.name}</h2>
              <p className="text-sm text-white/80">{project.category}</p>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="mt-3 grid grid-cols-3 gap-3">
          {[
            { icon: Download, label: 'Downloads', val: project.downloads > 0 ? project.downloads.toLocaleString() : '—', color: 'text-blue-400' },
            { icon: Star, label: 'Rating', val: project.rating > 0 ? `${project.rating}` : '—', color: 'text-amber-400' },
            { icon: Smartphone, label: 'Version', val: project.version, color: 'text-violet-400' },
          ].map((s) => (
            <Card key={s.label} className="p-3 text-center">
              <s.icon size={16} className={`mx-auto mb-1 ${s.color}`} />
              <p className="text-sm font-bold text-white">{s.val}</p>
              <p className="text-[10px] text-white/40">{s.label}</p>
            </Card>
          ))
          }
        </div>

        {/* Quick actions */}
        <div className="mt-4 grid grid-cols-2 gap-3">
          <button className="flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-blue-500 to-violet-600 py-3 text-sm font-semibold text-white shadow-lg shadow-blue-500/25 transition active:scale-95">
            <RefreshCw size={15} /> Deploy Update
          </button>
          <button className="flex items-center justify-center gap-2 rounded-2xl border border-white/10 bg-white/5 py-3 text-sm font-semibold text-white/80 transition hover:bg-white/10 active:scale-95">
            <Eye size={15} /> Preview
          </button>
        </div>

        {/* Repo sync */}
        <h3 className="mb-3 mt-6 text-xs font-semibold uppercase tracking-wider text-white/40">
          Repository Sync
        </h3>
        <Card className="p-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/5">
              <GitBranch size={18} className="text-white" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-white">{project.repo}</p>
              <p className="text-[11px] text-white/40">main · last synced {project.lastDeployed}</p>
            </div>
            <Pill className="bg-emerald-500/15 text-emerald-400">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" /> Synced
            </Pill>
          </div>
        </Card>

        {/* Version history / deployments */}
        <h3 className="mb-3 mt-6 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-white/40">
          <History size={12} /> Version History
        </h3>
        <Card className="divide-y divide-white/[0.04]">
          {project.deployments.map((d) => (
            <div key={d.id} className="flex items-center gap-3 p-3.5">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-white/5">
                {d.platform === 'web' ? <Globe size={15} className="text-white/60" /> : <Smartphone size={15} className="text-white/60" />}
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-white">{d.version}</p>
                <p className="text-[11px] text-white/40">{d.date}{d.downloads ? ` · ${d.downloads.toLocaleString()} downloads` : ''}</p>
              </div>
              <Pill
                className={
                  d.status === 'live'
                    ? 'bg-emerald-500/15 text-emerald-400'
                    : d.status === 'in_review'
                    ? 'bg-amber-500/15 text-amber-400'
                    : 'bg-white/10 text-white/50'
                }
              >
                <StatusDot status={d.status} /> {statusLabels[d.status] || d.status}
              </Pill>
            </div>
          ))}
        </Card>

        {/* Features */}
        <h3 className="mb-3 mt-6 text-xs font-semibold uppercase tracking-wider text-white/40">
          Features
        </h3>
        <div className="flex flex-wrap gap-2">
          {project.features.map((f) => (
            <span key={f.label} className="rounded-xl border border-white/[0.06] bg-white/[0.03] px-3 py-2 text-xs text-white/70">
              {f.label}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
