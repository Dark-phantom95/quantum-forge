import { useRef, useState, type DragEvent } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Upload,
  FileArchive,
  X,
  AlertTriangle,
  CheckCircle2,
  Package,
  Smartphone,
  RefreshCw,
  ArrowRight,
  Loader2,
} from 'lucide-react';
import { useApp } from '../lib/store';
import { api } from '../lib/api';
import { ACCEPTED_EXTENSIONS } from '../lib/data';
import type { ImportedPackage } from '../lib/types';
import { ScreenHeader, PrimaryButton, GlowOrb, Card } from '../components/ui';

export function ImportScreen() {
  const { setImportedPackage, setFlowStep, exitFlow } = useApp();
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pkg, setPkg] = useState<ImportedPackage | null>(null);
  const [validating, setValidating] = useState(false);

  const handleFile = async (file: File | undefined | null) => {
    if (!file) return;
    setError(null);
    setValidating(true);
    try {
      const result = await api.validatePackage(file.name, file.size);
      if (!result.ok || !result.package) {
        setPkg(null);
        setError(result.error || 'Invalid file.');
      } else {
        setPkg(result.package);
      }
    } catch {
      setPkg(null);
      setError('Failed to validate package. Please try again.');
    } finally {
      setValidating(false);
    }
  };

  const onDrop = (e: DragEvent) => {
    e.preventDefault();
    setDragging(false);
    handleFile(e.dataTransfer.files?.[0]);
  };

  const proceed = () => {
    if (!pkg) return;
    setImportedPackage(pkg);
    setFlowStep('importing');
  };

  const reset = () => {
    setPkg(null);
    setError(null);
    if (inputRef.current) inputRef.current.value = '';
  };

  return (
    <div className="flex h-full flex-col">
      <GlowOrb className="-top-10 right-0 h-40 w-40 bg-blue-600/15" />
      <ScreenHeader
        title="Import Package"
        subtitle="Upload an existing Android build"
        onBack={exitFlow}
        right={
          <button onClick={exitFlow} className="flex h-9 w-9 items-center justify-center rounded-xl bg-white/5 text-white/60 hover:bg-white/10">
            <X size={18} />
          </button>
        }
      />

      <div className="flex-1 overflow-y-auto px-5 pb-4">
        <p className="mb-4 text-sm text-white/50">
          Import a compiled Android package and we'll validate, extract its details, and deploy it to the Play Store — no manual setup required.
        </p>

        {/* Drop zone / file preview */}
        <input
          ref={inputRef}
          type="file"
          accept={ACCEPTED_EXTENSIONS.map((e) => `.${e}`).join(',')}
          className="hidden"
          onChange={(e) => handleFile(e.target.files?.[0])}
        />

        <AnimatePresence mode="wait">
          {validating ? (
            <motion.div
              key="validating"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="flex w-full flex-col items-center justify-center rounded-3xl border-2 border-blue-500/30 bg-blue-500/[0.04] p-8 text-center"
            >
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 1.5, repeat: Infinity, ease: 'linear' }}
                className="mb-3 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-500 to-violet-600 shadow-lg shadow-violet-600/30"
              >
                <Loader2 size={28} className="text-white" />
              </motion.div>
              <p className="text-sm font-semibold text-white">Validating package...</p>
              <p className="mt-1 text-[11px] text-white/40">Checking integrity & extracting manifest</p>
            </motion.div>
          ) : pkg ? (
            <motion.div
              key="preview"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
            >
              <Card className="border-emerald-500/20 bg-emerald-500/[0.04] p-4">
                <div className="flex items-start gap-3">
                  <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600">
                    <FileArchive size={24} className="text-white" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold text-white">{pkg.fileName}</p>
                    <p className="text-[11px] text-white/40">
                      {pkg.format.toUpperCase()} · {pkg.sizeMB.toFixed(2)} MB
                    </p>
                  </div>
                  <button
                    onClick={reset}
                    className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/5 text-white/50 hover:bg-white/10"
                  >
                    <X size={15} />
                  </button>
                </div>
                <div className="mt-3 flex items-center gap-2 rounded-xl bg-emerald-500/10 p-2.5">
                  <CheckCircle2 size={15} className="shrink-0 text-emerald-400" />
                  <span className="text-[11px] text-emerald-300/90">
                    File validated · ready to extract manifest
                  </span>
                </div>
              </Card>

              {/* Quick metadata preview */}
              <div className="mt-3 grid grid-cols-2 gap-3">
                <Card className="p-3">
                  <p className="text-[10px] text-white/40">App Name</p>
                  <p className="mt-0.5 truncate text-sm font-semibold text-white">{pkg.appName}</p>
                </Card>
                <Card className="p-3">
                  <p className="text-[10px] text-white/40">Version</p>
                  <p className="mt-0.5 text-sm font-semibold text-white">{pkg.versionName}</p>
                </Card>
              </div>
            </motion.div>
          ) : (
            <motion.button
              key="dropzone"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              onClick={() => inputRef.current?.click()}
              onDragOver={(e) => {
                e.preventDefault();
                setDragging(true);
              }}
              onDragLeave={() => setDragging(false)}
              onDrop={onDrop}
              className={`flex w-full flex-col items-center justify-center rounded-3xl border-2 border-dashed p-8 text-center transition ${
                dragging
                  ? 'border-blue-500 bg-blue-500/10'
                  : 'border-white/15 bg-white/[0.02] hover:border-blue-500/50 hover:bg-white/[0.04]'
              }`}
            >
              <motion.div
                animate={dragging ? { y: -4 } : { y: 0 }}
                className="mb-3 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-500 to-violet-600 shadow-lg shadow-violet-600/30"
              >
                <Upload size={28} className="text-white" />
              </motion.div>
              <p className="text-sm font-semibold text-white">
                {dragging ? 'Drop to upload' : 'Tap to browse or drag a file'}
              </p>
              <p className="mt-1 text-[11px] text-white/40">
                Supports APK, AAB, and ZIP up to 150 MB
              </p>
            </motion.button>
          )}
        </AnimatePresence>

        {/* Error state */}
        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-3"
            >
              <Card className="border-rose-500/30 bg-rose-500/[0.06] p-3.5">
                <div className="flex items-start gap-2.5">
                  <AlertTriangle size={17} className="mt-0.5 shrink-0 text-rose-400" />
                  <div className="flex-1">
                    <p className="text-xs font-semibold text-rose-300">Validation failed</p>
                    <p className="mt-0.5 text-[11px] leading-relaxed text-rose-300/70">{error}</p>
                  </div>
                  <button
                    onClick={() => inputRef.current?.click()}
                    className="flex shrink-0 items-center gap-1 rounded-lg bg-rose-500/15 px-2.5 py-1.5 text-[11px] font-semibold text-rose-300 hover:bg-rose-500/25"
                  >
                    <RefreshCw size={11} /> Retry
                  </button>
                </div>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Format info */}
        <div className="mt-6">
          <p className="mb-3 text-xs font-semibold uppercase tracking-wider text-white/40">
            Supported Formats
          </p>
          <div className="space-y-2.5">
            {[
              { icon: Package, name: 'AAB', desc: 'Android App Bundle — preferred for Play Store', color: 'text-emerald-400' },
              { icon: Smartphone, name: 'APK', desc: 'Android Package — standalone installable', color: 'text-blue-400' },
              { icon: FileArchive, name: 'ZIP', desc: 'Zipped project or bundle archive', color: 'text-violet-400' },
            ].map((f) => (
              <div key={f.name} className="flex items-center gap-3 rounded-2xl border border-white/[0.06] bg-white/[0.02] p-3">
                <f.icon size={18} className={f.color} />
                <div>
                  <p className="text-xs font-semibold text-white">{f.name}</p>
                  <p className="text-[11px] text-white/40">{f.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* What happens next */}
        <div className="mt-6 rounded-2xl border border-white/[0.06] bg-white/[0.02] p-4">
          <p className="mb-3 text-xs font-semibold text-white/50">What happens next</p>
          <div className="space-y-2.5">
            {[
              'Validate file integrity & manifest',
              'Run compatibility & security checks',
              'Review extracted details, then deploy',
            ].map((step, i) => (
              <div key={i} className="flex items-center gap-3">
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-blue-500/15 text-[11px] font-bold text-blue-400">
                  {i + 1}
                </span>
                <span className="text-xs text-white/60">{step}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Sticky CTA */}
      <div className="border-t border-white/[0.06] bg-[#0a0a12]/80 p-5 backdrop-blur-xl">
        <PrimaryButton onClick={proceed} disabled={!pkg}>
          Validate & Extract <ArrowRight size={16} />
        </PrimaryButton>
      </div>
    </div>
  );
}
