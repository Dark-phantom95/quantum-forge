import { useState } from 'react';
import { motion } from 'framer-motion';
import { Sparkles, ArrowRight, X, Lightbulb, Package } from 'lucide-react';
import { useApp } from '../lib/store';
import { examplePrompts } from '../lib/data';
import { ScreenHeader, PrimaryButton, GlowOrb } from '../components/ui';

export function CreateScreen() {
  const { idea, setIdea, setFlowStep, exitFlow, startImport } = useApp();
  const [focused, setFocused] = useState(false);

  const handleGenerate = () => {
    if (idea.trim().length < 5) return;
    setFlowStep('generating');
  };

  return (
    <div className="flex h-full flex-col">
      <GlowOrb className="-top-10 right-0 h-40 w-40 bg-violet-600/20" />
      <ScreenHeader
        title="Create New App"
        subtitle="Describe your idea in plain words"
        onBack={exitFlow}
        right={
          <button onClick={exitFlow} className="flex h-9 w-9 items-center justify-center rounded-xl bg-white/5 text-white/60 hover:bg-white/10">
            <X size={18} />
          </button>
        }
      />

      <div className="flex-1 overflow-y-auto px-5 pb-4">
        {/* Prompt card */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative rounded-3xl border border-white/10 bg-gradient-to-br from-white/[0.06] to-transparent p-4"
        >
          <div className="mb-3 flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-blue-500 to-violet-600">
              <Sparkles size={16} className="text-white" />
            </div>
            <span className="text-sm font-semibold text-white">AI Prompt</span>
          </div>
          <textarea
            autoFocus
            value={idea}
            onChange={(e) => setIdea(e.target.value)}
            onFocus={() => setFocused(true)}
            onBlur={() => setFocused(false)}
            placeholder="e.g. A meditation app with guided sessions, mood tracking, and daily streaks..."
            className={`h-32 w-full resize-none rounded-2xl bg-black/30 p-4 text-sm text-white placeholder:text-white/30 outline-none transition ${focused ? 'ring-2 ring-blue-500/50' : 'ring-1 ring-white/10'}`}
          />
          <div className="mt-2 flex items-center justify-between px-1">
            <span className="text-[11px] text-white/30">{idea.length} characters</span>
            <span className="text-[11px] text-white/30">Be as descriptive as you like</span>
          </div>
        </motion.div>

        {/* Example prompts */}
        <div className="mt-6 mb-3 flex items-center gap-2">
          <Lightbulb size={14} className="text-amber-400" />
          <span className="text-xs font-semibold uppercase tracking-wider text-white/40">Try an example</span>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {examplePrompts.map((ex, i) => (
            <motion.button
              key={ex.title}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.05 * i }}
              whileTap={{ scale: 0.96 }}
              onClick={() => setIdea(ex.prompt)}
              className="rounded-2xl border border-white/[0.06] bg-white/[0.03] p-3 text-left transition hover:border-blue-500/30 hover:bg-white/[0.05]"
            >
              <span className="text-2xl">{ex.emoji}</span>
              <p className="mt-1.5 text-sm font-semibold text-white">{ex.title}</p>
              <p className="mt-0.5 text-[11px] leading-tight text-white/40">{ex.prompt}</p>
            </motion.button>
          ))}
        </div>

        {/* What happens next */}
        <div className="mt-6 rounded-2xl border border-white/[0.06] bg-white/[0.02] p-4">
          <p className="mb-3 text-xs font-semibold text-white/50">What happens next</p>
          <div className="space-y-2.5">
            {[
              'AI analyzes your description',
              'Generates project details & screens',
              'Preview the build before deploying',
            ].map((step, i) => (
              <div key={i} className="flex items-center gap-3">
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-blue-500/15 text-[11px] font-bold text-blue-400">
                  {i + 1}
                </span>
                <span className="text-xs text-white/60">{step}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Sticky CTA */}
      <div className="border-t border-white/[0.06] bg-[#0a0a12]/80 p-5 backdrop-blur-xl">
        <PrimaryButton onClick={handleGenerate} disabled={idea.trim().length < 5}>
          Generate App <ArrowRight size={16} />
        </PrimaryButton>
        <button
          onClick={startImport}
          className="mt-3 flex w-full items-center justify-center gap-2 text-xs font-medium text-white/50 transition hover:text-blue-400"
        >
          <Package size={14} /> or import an existing package (APK / AAB / ZIP)
        </button>
      </div>
    </div>
  );
}
