import { motion } from 'framer-motion';
import {
  ArrowRight,
  Package,
  Hash,
  Cpu,
  Lock,
  ShieldCheck,
  Layers,
  Smartphone,
  CheckCircle2,
} from 'lucide-react';
import { useApp } from '../lib/store';
import {
  Card,
  ScreenHeader,
  PrimaryButton,
  GhostButton,
  GlowOrb,
  Pill,
} from '../components/ui';

const sdkNames: Record<number, string> = {
  24: 'Android 7.0 (Nougat)',
  25: 'Android 7.1',
  26: 'Android 8.0 (Oreo)',
  27: 'Android 8.1',
  28: 'Android 9 (Pie)',
  29: 'Android 10',
  30: 'Android 11',
  31: 'Android 12',
  32: 'Android 12L',
  33: 'Android 13',
  34: 'Android 14',
};

export function ImportDetailsScreen() {
  const { importedPackage, generatedProject, setFlowStep, exitFlow } = useApp();

  if (!importedPackage || !generatedProject) return null;
  const pkg = importedPackage;
  const p = generatedProject;

  return (
    <div className="flex h-full flex-col">
      <GlowOrb className="-top-10 -right-10 h-40 w-40 bg-violet-600/15" />
      <ScreenHeader
        title="Package Details"
        subtitle="Extracted & validated — review before deploy"
        onBack={exitFlow}
      />

      <div className="flex-1 overflow-y-auto px-5 pb-4">
        {/* Banner */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-blue-600 to-violet-700 p-5"
        >
          <div className="absolute -right-4 -top-4 h-24 w-24 rounded-full bg-white/15 blur-xl" />
          <div className="relative flex items-start gap-4">
            <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-white/20 text-4xl backdrop-blur-sm">
              📦
            </div>
            <div className="flex-1">
              <Pill className="bg-white/20 text-white">
                <CheckCircle2 size={11} /> {pkg.format.toUpperCase()} Validated
              </Pill>
              <h2 className="mt-1.5 text-2xl font-bold text-white">{pkg.appName}</h2>
              <p className="text-sm text-white/80">{pkg.packageName}</p>
            </div>
          </div>
        </motion.div>

        {/* Core metadata grid */}
        <div className="mt-3 grid grid-cols-2 gap-3">
          <DetailCard icon={Hash} label="Version" value={`${pkg.versionName} (${pkg.versionCode})`} color="text-blue-400" />
          <DetailCard icon={Package} label="Size" value={`${pkg.sizeMB.toFixed(2)} MB`} color="text-violet-400" />
          <DetailCard icon={Cpu} label="Min SDK" value={`API ${pkg.minSdk}`} color="text-emerald-400" />
          <DetailCard icon={Smartphone} label="Target SDK" value={`API ${pkg.targetSdk}`} color="text-amber-400" />
        </div>

        {/* Compatibility status */}
        <h3 className="mb-3 mt-6 px-1 text-xs font-semibold uppercase tracking-wider text-white/40">
          Compatibility
        </h3>
        <Card className="divide-y divide-white/[0.04]">
          <Row icon={Cpu} label="Minimum Android" value={sdkNames[pkg.minSdk] || `API ${pkg.minSdk}`} ok />
          <Row icon={Smartphone} label="Target Android" value={sdkNames[pkg.targetSdk] || `API ${pkg.targetSdk}`} ok />
          <Row icon={Layers} label="Architectures" value={pkg.architectures.join(', ')} ok />
          <Row icon={ShieldCheck} label="Signature" value="Verified (v2 scheme)" ok />
        </Card>

        {/* Permissions */}
        <h3 className="mb-3 mt-6 px-1 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-white/40">
          <Lock size={12} /> Permissions ({pkg.permissions.length})
        </h3>
        <Card className="p-3.5">
          <div className="flex flex-wrap gap-2">
            {pkg.permissions.map((perm) => {
              const short = perm.replace('android.permission.', '');
              return (
                <span
                  key={perm}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-white/[0.06] bg-white/[0.03] px-2.5 py-1.5 text-[11px] text-white/70"
                >
                  <Lock size={10} className="text-amber-400" />
                  {short}
                </span>
              );
            })}
          </div>
        </Card>

        {/* Launch activity */}
        <h3 className="mb-3 mt-6 px-1 text-xs font-semibold uppercase tracking-wider text-white/40">
          Launch Activity
        </h3>
        <Card className="p-3.5">
          <code className="text-[11px] text-blue-300">{pkg.launchActivity}</code>
        </Card>

        {/* Tech / screens summary (reuse from generated project) */}
        <h3 className="mb-3 mt-6 px-1 text-xs font-semibold uppercase tracking-wider text-white/40">
          Build Info
        </h3>
        <div className="flex flex-wrap gap-2">
          {p.techStack.map((t) => (
            <span
              key={t.name}
              className="inline-flex items-center gap-1.5 rounded-xl border border-white/[0.06] bg-white/[0.03] px-3 py-2 text-xs text-white/70"
            >
              {t.name}
              <span className="text-white/30">· {t.category}</span>
            </span>
          ))}
        </div>
      </div>

      {/* Sticky CTA */}
      <div className="border-t border-white/[0.06] bg-[#0a0a12]/80 p-5 backdrop-blur-xl">
        <div className="flex gap-3">
          <GhostButton onClick={() => setFlowStep('import')} className="flex-1">
            Choose Another
          </GhostButton>
          <div className="flex-[1.5]">
            <PrimaryButton onClick={() => setFlowStep('connect')}>
              Continue to Deploy <ArrowRight size={16} />
            </PrimaryButton>
          </div>
        </div>
      </div>
    </div>
  );
}

function DetailCard({
  icon: Icon,
  label,
  value,
  color,
}: {
  icon: typeof Hash;
  label: string;
  value: string;
  color: string;
}) {
  return (
    <Card className="p-3.5">
      <Icon size={16} className={`mb-1.5 ${color}`} />
      <p className="text-[10px] text-white/40">{label}</p>
      <p className="mt-0.5 text-sm font-semibold text-white">{value}</p>
    </Card>
  );
}

function Row({
  icon: Icon,
  label,
  value,
  ok,
}: {
  icon: typeof Cpu;
  label: string;
  value: string;
  ok?: boolean;
}) {
  return (
    <div className="flex items-center gap-3 p-3.5">
      <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-white/5">
        <Icon size={16} className="text-white/60" />
      </div>
      <div className="flex-1">
        <p className="text-sm font-medium text-white">{label}</p>
        <p className="text-[11px] text-white/40">{value}</p>
      </div>
      {ok && <CheckCircle2 size={16} className="text-emerald-400" />}
    </div>
  );
}
