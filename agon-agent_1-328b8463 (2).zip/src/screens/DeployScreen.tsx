import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Check,
  Loader2,
  Rocket,
  GitBranch,
  Tag,
  Upload,
  Globe,
  ShieldCheck,
} from 'lucide-react';
import { useApp } from '../lib/store';
import { api } from '../lib/api';
import { deployTasks, importDeployTasks } from '../lib/data';
import type { DeployTask } from '../lib/types';
import { GlowOrb } from '../components/ui';

const taskIcons: Record<string, typeof Rocket> = {
  build: Rocket,
  validate: ShieldCheck,
  repo: GitBranch,
  version: Tag,
  store: Upload,
  live: Globe,
};

const STEP_DURATION = 1700;

export function DeployScreen() {
  const { generatedProject, deployMode, setFlowStep } = useApp();
  const baseTasks = deployMode === 'import' ? importDeployTasks : deployTasks;

  const [tasks, setTasks] = useState<DeployTask[]>(() =>
    baseTasks.map((t) => ({ ...t, status: 'pending' as const }))
  );
  const [activeIdx, setActiveIdx] = useState(0);

  // Single guarded effect drives the whole pipeline. A ref prevents StrictMode
  // double-firing and any accidental re-entry, making deployment reliable.
  const startedRef = useRef(false);

  useEffect(() => {
    if (startedRef.current) return;
    startedRef.current = true;

    // Notify backend about the deployment (fire and forget)
    if (generatedProject) {
      api.startDeployment(generatedProject, deployMode).catch(() => {});
    }

    let cancelled = false;
    let current = 0;

    const tick = () => {
      if (cancelled) return;
      // Mark current task active.
      setTasks((prev) =>
        prev.map((t, i) =>
          i === current ? { ...t, status: 'active' } : t
        )
      );
      // After the duration, mark done and advance.
      setTimeout(() => {
        if (cancelled) return;
        setTasks((prev) =>
          prev.map((t, i) =>
            i === current ? { ...t, status: 'done' } : t
          )
        );
        current += 1;
        if (current < baseTasks.length) {
          tick();
        } else {
          // Pipeline complete — advance to success after a brief beat.
          setTimeout(() => {
            if (!cancelled) setFlowStep('success');
          }, 900);
        }
      }, STEP_DURATION);
    };

    tick();

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const doneCount = tasks.filter((t) => t.status === 'done').length;
  const progress = (doneCount / tasks.length) * 100;
  const isImport = deployMode === 'import';

  return (
    <div className="relative flex h-full flex-col items-center justify-center px-6">
      <GlowOrb className="top-10 left-1/2 h-48 w-48 -translate-x-1/2 bg-blue-600/25" />

      {/* Rocket animation */}
      <motion.div
        animate={{ y: [0, -8, 0] }}
        transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
        className="relative mb-6 flex h-20 w-20 items-center justify-center rounded-3xl bg-gradient-to-br from-blue-500 to-violet-600 shadow-lg shadow-violet-600/40"
      >
        {isImport ? <ShieldCheck size={36} className="text-white" /> : <Rocket size={36} className="text-white" />}
        <motion.div
          animate={{ scale: [1, 1.3, 1], opacity: [0.5, 0.2, 0.5] }}
          transition={{ duration: 1.5, repeat: Infinity }}
          className="absolute -bottom-6 h-8 w-10 rounded-full bg-gradient-to-b from-orange-400 to-transparent blur-md"
        />
      </motion.div>

      <h2 className="text-xl font-bold text-white">
        {isImport ? 'Publishing package...' : `Deploying ${generatedProject?.name}...`}
      </h2>
      <p className="mt-1 text-sm text-white/40">
        {isImport
          ? 'Validating & publishing your imported build'
          : 'Building & publishing to production'}
      </p>

      {/* Progress bar */}
      <div className="mt-6 w-full max-w-[280px]">
        <div className="mb-2 flex justify-between text-[11px] text-white/40">
          <span>Deployment progress</span>
          <span>{Math.round(progress)}%</span>
        </div>
        <div className="h-2 w-full overflow-hidden rounded-full bg-white/10">
          <motion.div
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.5 }}
            className="h-full rounded-full bg-gradient-to-r from-blue-500 to-violet-500"
          />
        </div>
      </div>

      {/* Task list */}
      <div className="mt-8 w-full max-w-[320px] space-y-2">
        <AnimatePresence>
          {tasks.map((task) => {
            const Icon = taskIcons[task.id] || Rocket;
            return (
              <motion.div
                key={task.id}
                layout
                className={`flex items-center gap-3 rounded-2xl border p-3 transition ${
                  task.status === 'active'
                    ? 'border-blue-500/30 bg-blue-500/10'
                    : task.status === 'done'
                    ? 'border-emerald-500/20 bg-emerald-500/5'
                    : 'border-white/[0.04] bg-white/[0.02]'
                }`}
              >
                <div
                  className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${
                    task.status === 'done'
                      ? 'bg-emerald-500/20 text-emerald-400'
                      : task.status === 'active'
                      ? 'bg-blue-500/20 text-blue-400'
                      : 'bg-white/5 text-white/30'
                  }`}
                >
                  {task.status === 'done' ? (
                    <Check size={18} />
                  ) : task.status === 'active' ? (
                    <Loader2 size={18} className="animate-spin" />
                  ) : (
                    <Icon size={18} />
                  )}
                </div>
                <div className="flex-1">
                  <p
                    className={`text-sm font-medium ${
                      task.status === 'pending' ? 'text-white/40' : 'text-white'
                    }`}
                  >
                    {task.label}
                  </p>
                  <p className="text-[11px] text-white/30">{task.detail}</p>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
    </div>
  );
}
