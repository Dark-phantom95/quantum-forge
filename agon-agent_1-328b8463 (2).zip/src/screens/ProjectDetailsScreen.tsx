import { motion } from 'framer-motion';
import {
  Check,
  ArrowRight,
  Layers,
  Smartphone,
  Cpu,
  Edit3,
  Zap,
  Bell,
  Shield,
  BarChart3,
} from 'lucide-react';
import { useApp } from '../lib/store';
import { Card, ScreenHeader, PrimaryButton, GhostButton, GlowOrb, Pill } from '../components/ui';

const featureIcons: Record<string, typeof Zap> = {
  zap: Zap,
  bell: Bell,
  shield: Shield,
  'bar-chart': BarChart3,
  dumbbell: Zap,
  'trending-up': BarChart3,
  users: Zap,
  search: Zap,
  calendar: Zap,
  'shopping-cart': Zap,
  heart: Zap,
  'check-square': Zap,
  target: Zap,
  map: Zap,
  compass: Zap,
  bookmark: Zap,
  'share-2': Zap,
};

export function ProjectDetailsScreen() {
  const { generatedProject, setFlowStep, exitFlow } = useApp();
  if (!generatedProject) return null;
  const p = generatedProject;

  return (
    <div className="flex h-full flex-col">
      <GlowOrb className="-top-10 -right-10 h-40 w-40 bg-blue-600/15" />
      <ScreenHeader
        title="Review Project"
        subtitle="AI-generated details — edit anytime"
        onBack={exitFlow}
      />

      <div className="flex-1 overflow-y-auto px-5 pb-4">
        {/* Project banner */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className={`relative overflow-hidden rounded-3xl bg-gradient-to-br ${p.color} p-5`}
        >
          <div className="absolute -right-4 -top-4 h-24 w-24 rounded-full bg-white/15 blur-xl" />
          <div className="relative flex items-start gap-4">
            <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-white/20 text-4xl backdrop-blur-sm">
              {p.icon}
            </div>
            <div className="flex-1">
              <div className="mb-1 flex items-center gap-2">
                <Pill className="bg-white/20 text-white">
                  <Check size={11} /> Generated
                </Pill>
              </div>
              <h2 className="text-2xl font-bold text-white">{p.name}</h2>
              <p className="text-sm text-white/80">{p.tagline}</p>
            </div>
          </div>
          <p className="relative mt-3 text-xs leading-relaxed text-white/70">{p.description}</p>
        </motion.div>

        {/* Category & version */}
        <div className="mt-3 grid grid-cols-2 gap-3">
          <Card className="p-3.5">
            <p className="text-[11px] text-white/40">Category</p>
            <p className="mt-0.5 text-sm font-semibold text-white">{p.category}</p>
          </Card>
          <Card className="p-3.5">
            <p className="text-[11px] text-white/40">Version</p>
            <p className="mt-0.5 text-sm font-semibold text-white">{p.version}</p>
          </Card>
        </div>

        {/* Features */}
        <div className="mb-3 mt-6 flex items-center justify-between px-1">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-white/40">
            Features
          </h3>
          <button className="flex items-center gap-1 text-[11px] font-medium text-blue-400">
            <Edit3 size={11} /> Edit
          </button>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {p.features.map((f, i) => {
            const Icon = featureIcons[f.icon] || Zap;
            return (
              <motion.div
                key={f.label}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.05 * i }}
              >
                <Card className="flex items-center gap-2.5 p-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-blue-500/15">
                    <Icon size={16} className="text-blue-400" />
                  </div>
                  <span className="text-xs font-medium text-white">{f.label}</span>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Screens */}
        <h3 className="mb-3 mt-6 px-1 text-xs font-semibold uppercase tracking-wider text-white/40">
          App Screens
        </h3>
        <Card className="divide-y divide-white/[0.04]">
          {p.screens.map((s, i) => (
            <div key={s.name} className="flex items-center gap-3 p-3.5">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/5 text-[11px] font-bold text-white/50">
                {i + 1}
              </div>
              <div className="flex-1">
                <p className="flex items-center gap-1.5 text-sm font-medium text-white">
                  <Smartphone size={13} className="text-violet-400" /> {s.name}
                </p>
                <p className="text-[11px] text-white/40">{s.description}</p>
              </div>
            </div>
          ))}
        </Card>

        {/* Tech stack */}
        <h3 className="mb-3 mt-6 px-1 text-xs font-semibold uppercase tracking-wider text-white/40">
          <span className="inline-flex items-center gap-1.5">
            <Cpu size={12} /> Tech Stack
          </span>
        </h3>
        <div className="flex flex-wrap gap-2">
          {p.techStack.map((t) => (
            <span
              key={t.name}
              className="inline-flex items-center gap-1.5 rounded-xl border border-white/[0.06] bg-white/[0.03] px-3 py-2 text-xs text-white/70"
            >
              <Layers size={12} className="text-blue-400" />
              {t.name}
              <span className="text-white/30">· {t.category}</span>
            </span>
          ))}
        </div>
      </div>

      {/* Sticky CTA */}
      <div className="border-t border-white/[0.06] bg-[#0a0a12]/80 p-5 backdrop-blur-xl">
        <div className="flex gap-3">
          <GhostButton onClick={() => setFlowStep('idea')} className="flex-1">
            Regenerate
          </GhostButton>
          <div className="flex-[1.5]">
            <PrimaryButton onClick={() => setFlowStep('preview')}>
              Preview Build <ArrowRight size={16} />
            </PrimaryButton>
          </div>
        </div>
      </div>
    </div>
  );
}
