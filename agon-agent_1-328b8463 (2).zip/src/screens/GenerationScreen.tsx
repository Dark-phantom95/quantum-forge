import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Brain,
  Layers,
  Layout,
  Code2,
  Sparkles,
  Check,
  Loader2,
} from 'lucide-react';
import { useApp } from '../lib/store';
import { generationSteps } from '../lib/data';
import { GlowOrb } from '../components/ui';

const iconMap: Record<string, typeof Brain> = {
  brain: Brain,
  layers: Layers,
  layout: Layout,
  code: Code2,
  sparkles: Sparkles,
};

export function GenerationScreen() {
  const { idea, setFlowStep, generateProject } = useApp();
  const [activeStep, setActiveStep] = useState(0);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    generateProject();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (activeStep >= generationSteps.length) return;
    const timer = setTimeout(() => {
      setActiveStep((s) => s + 1);
      setProgress(((activeStep + 1) / generationSteps.length) * 100);
    }, 1400);
    return () => clearTimeout(timer);
  }, [activeStep]);

  useEffect(() => {
    if (activeStep >= generationSteps.length) {
      const t = setTimeout(() => setFlowStep('details'), 800);
      return () => clearTimeout(t);
    }
  }, [activeStep, setFlowStep]);

  return (
    <div className="relative flex h-full flex-col items-center justify-center px-6">
      <GlowOrb className="top-0 left-1/2 h-56 w-56 -translate-x-1/2 bg-violet-600/25" />
      <GlowOrb className="bottom-10 right-0 h-40 w-40 bg-blue-600/20" />

      {/* Animated orb */}
      <motion.div
        animate={{ scale: [1, 1.08, 1], rotate: [0, 180, 360] }}
        transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut' }}
        className="relative mb-8 flex h-28 w-28 items-center justify-center"
      >
        <div className="absolute inset-0 rounded-full bg-gradient-to-br from-blue-500 to-violet-600 blur-xl opacity-60" />
        <div className="relative flex h-24 w-24 items-center justify-center rounded-full bg-gradient-to-br from-blue-500 to-violet-600">
          <Sparkles size={36} className="text-white" />
        </div>
        <motion.div
          animate={{ rotate: [0, 360] }}
          transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
          className="absolute -inset-2 rounded-full border-2 border-transparent border-t-blue-400 border-r-violet-400"
        />
      </motion.div>

      <motion.h2
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-xl font-bold text-white"
      >
        Building your app...
      </motion.h2>
      <p className="mt-1 max-w-[260px] text-center text-sm text-white/40">
        Our AI is crafting a complete project from your idea
      </p>

      {/* Progress bar */}
      <div className="mt-6 w-full max-w-[280px]">
        <div className="mb-2 flex justify-between text-[11px] text-white/40">
          <span>Progress</span>
          <span>{Math.round(progress)}%</span>
        </div>
        <div className="h-2 w-full overflow-hidden rounded-full bg-white/10">
          <motion.div
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
            className="h-full rounded-full bg-gradient-to-r from-blue-500 to-violet-500"
          />
        </div>
      </div>

      {/* Steps */}
      <div className="mt-8 w-full max-w-[320px] space-y-2">
        {generationSteps.map((step, i) => {
          const Icon = iconMap[step.icon] || Sparkles;
          const done = i < activeStep;
          const active = i === activeStep;
          return (
            <AnimatePresence key={step.id}>
              <motion.div
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: done || active ? 1 : 0.3, x: 0 }}
                className={`flex items-center gap-3 rounded-2xl border p-3 transition ${
                  active
                    ? 'border-blue-500/30 bg-blue-500/10'
                    : done
                    ? 'border-emerald-500/20 bg-emerald-500/5'
                    : 'border-white/[0.04] bg-white/[0.02]'
                }`}
              >
                <div
                  className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${
                    done
                      ? 'bg-emerald-500/20 text-emerald-400'
                      : active
                      ? 'bg-blue-500/20 text-blue-400'
                      : 'bg-white/5 text-white/30'
                  }`}
                >
                  {done ? (
                    <Check size={18} />
                  ) : active ? (
                    <Loader2 size={18} className="animate-spin" />
                  ) : (
                    <Icon size={18} />
                  )}
                </div>
                <div className="flex-1">
                  <p className={`text-sm font-medium ${done || active ? 'text-white' : 'text-white/40'}`}>
                    {step.label}
                  </p>
                  <p className="text-[11px] text-white/30">{step.detail}</p>
                </div>
              </motion.div>
            </AnimatePresence>
          );
        })}
      </div>
    </div>
  );
}
