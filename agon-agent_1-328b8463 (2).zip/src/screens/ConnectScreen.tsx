import { motion } from 'framer-motion';
import { ArrowRight, Github, Play, Check, Link2, Shield, Zap } from 'lucide-react';
import { useApp } from '../lib/store';
import { Card, ScreenHeader, PrimaryButton, GhostButton, GlowOrb, Pill } from '../components/ui';

export function ConnectScreen() {
  const { githubConnected, playConnected, toggleGithub, togglePlay, setFlowStep, exitFlow, deployMode } = useApp();
  const allConnected = githubConnected && playConnected;
  // Context-aware back navigation: imported apps return to package details,
  // generated apps return to the preview.
  const backStep = deployMode === 'import' ? 'import-details' : 'preview';

  return (
    <div className="flex h-full flex-col">
      <GlowOrb className="top-10 -left-10 h-40 w-40 bg-blue-600/15" />
      <ScreenHeader title="Connect Accounts" subtitle="Link your deployment targets" onBack={exitFlow} />

      <div className="flex-1 overflow-y-auto px-5 pb-4">
        <p className="mb-4 text-sm text-white/50">
          Connect your accounts to enable automatic repository sync, version management, and one-tap store publishing.
        </p>

        {/* GitHub */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
          <Card className={`p-4 ${githubConnected ? 'border-emerald-500/20' : ''}`}>
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-white/5">
                <Github size={24} className="text-white" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <p className="text-sm font-semibold text-white">GitHub</p>
                  {githubConnected && (
                    <Pill className="bg-emerald-500/15 text-emerald-400">
                      <Check size={10} /> Connected
                    </Pill>
                  )}
                </div>
                <p className="text-[11px] text-white/40">
                  {githubConnected ? 'quantum-forge · 42 repos' : 'Repository & version control'}
                </p>
              </div>
            </div>
            {githubConnected ? (
              <div className="mt-3 flex items-center gap-2 rounded-xl bg-emerald-500/5 p-2.5">
                <Link2 size={14} className="text-emerald-400" />
                <span className="text-[11px] text-emerald-400/80">Auto-sync enabled · main branch</span>
              </div>
            ) : (
              <button
                onClick={toggleGithub}
                className="mt-3 w-full rounded-xl border border-white/10 bg-white/5 py-2.5 text-xs font-semibold text-white transition hover:bg-white/10"
              >
                Connect GitHub
              </button>
            )}
          </Card>
        </motion.div>

        {/* Google Play */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.08 }} className="mt-3">
          <Card className={`p-4 ${playConnected ? 'border-emerald-500/20' : ''}`}>
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-green-500 to-emerald-600">
                <Play size={22} className="fill-white text-white" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <p className="text-sm font-semibold text-white">Google Play</p>
                  {playConnected && (
                    <Pill className="bg-emerald-500/15 text-emerald-400">
                      <Check size={10} /> Connected
                    </Pill>
                  )}
                </div>
                <p className="text-[11px] text-white/40">
                  {playConnected ? 'Developer Console · Play Console' : 'Publish to Play Store'}
                </p>
              </div>
            </div>
            {playConnected ? (
              <div className="mt-3 flex items-center gap-2 rounded-xl bg-emerald-500/5 p-2.5">
                <Link2 size={14} className="text-emerald-400" />
                <span className="text-[11px] text-emerald-400/80">Production track · ready to publish</span>
              </div>
            ) : (
              <button
                onClick={togglePlay}
                className="mt-3 w-full rounded-xl border border-white/10 bg-white/5 py-2.5 text-xs font-semibold text-white transition hover:bg-white/10"
              >
                Connect Google Play
              </button>
            )}
          </Card>
        </motion.div>

        {/* What you get */}
        <div className="mt-6 rounded-2xl border border-white/[0.06] bg-white/[0.02] p-4">
          <p className="mb-3 text-xs font-semibold text-white/50">What you get</p>
          <div className="space-y-3">
            {[
              { icon: Zap, title: 'Instant deploys', desc: 'Ship updates with one tap' },
              { icon: Shield, title: 'Secure & encrypted', desc: 'OAuth 2.0 protected connections' },
              { icon: Github, title: 'Auto repo sync', desc: 'Every build pushed to GitHub' },
            ].map((item) => (
              <div key={item.title} className="flex items-center gap-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-500/15">
                  <item.icon size={15} className="text-blue-400" />
                </div>
                <div>
                  <p className="text-xs font-medium text-white">{item.title}</p>
                  <p className="text-[10px] text-white/40">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Sticky CTA */}
      <div className="border-t border-white/[0.06] bg-[#0a0a12]/80 p-5 backdrop-blur-xl">
        <div className="flex gap-3">
          <GhostButton onClick={() => setFlowStep(backStep)} className="flex-1">
            Back
          </GhostButton>
          <div className="flex-[1.5]">
            <PrimaryButton onClick={() => setFlowStep('deploy')} disabled={!allConnected}>
              {allConnected ? 'Deploy Now' : 'Connect both to continue'} <ArrowRight size={16} />
            </PrimaryButton>
          </div>
        </div>
      </div>
    </div>
  );
}
