import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowRight,
  Home,
  Search,
  Bell,
  User,
  Star,
  Heart,
  ShoppingBag,
  TrendingUp,
  ArrowLeft,
} from 'lucide-react';
import { useApp } from '../lib/store';
import { ScreenHeader, PrimaryButton, GlowOrb, Pill } from '../components/ui';

export function PreviewScreen() {
  const { generatedProject, setFlowStep, exitFlow } = useApp();
  const [activeScreen, setActiveScreen] = useState(0);
  if (!generatedProject) return null;
  const p = generatedProject;

  const screens = p.screens;

  return (
    <div className="flex h-full flex-col">
      <GlowOrb className="-top-10 right-0 h-40 w-40 bg-violet-600/15" />
      <ScreenHeader
        title="Live Preview"
        subtitle={`${p.name} · interactive mockup`}
        onBack={exitFlow}
        right={
          <Pill className="bg-emerald-500/15 text-emerald-400">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
            Live
          </Pill>
        }
      />

      {/* Screen tabs */}
      <div className="flex gap-2 overflow-x-auto px-5 pb-3 scrollbar-hide">
        {screens.map((s, i) => (
          <button
            key={s.name}
            onClick={() => setActiveScreen(i)}
            className={`shrink-0 rounded-full px-3.5 py-1.5 text-xs font-medium transition ${
              activeScreen === i
                ? 'bg-blue-500 text-white'
                : 'bg-white/5 text-white/50'
            }`}
          >
            {s.name}
          </button>
        ))}
      </div>

      {/* Device preview */}
      <div className="flex flex-1 items-center justify-center px-5">
        <div className="relative w-full max-w-[240px]">
          <div className="overflow-hidden rounded-[2rem] border-[6px] border-[#1a1a26] bg-[#0d0d16] shadow-2xl shadow-black/50">
            {/* Phone status */}
            <div className="flex items-center justify-between bg-black px-4 py-1.5 text-[9px] text-white/60">
              <span>9:41</span>
              <div className="h-2.5 w-12 rounded-full bg-black" />
              <span>100%</span>
            </div>

            <AnimatePresence mode="wait">
              <motion.div
                key={activeScreen}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.25 }}
                className="h-[340px] overflow-y-auto"
              >
                <PreviewContent screenIndex={activeScreen} project={p} />
              </motion.div>
            </AnimatePresence>

            {/* Bottom nav of preview app */}
            <div className="flex items-center justify-around border-t border-white/5 bg-black/40 px-2 py-2">
              {[Home, Search, Bell, User].map((Icon, i) => (
                <Icon
                  key={i}
                  size={16}
                  className={i === 0 ? 'text-blue-400' : 'text-white/30'}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      <p className="px-8 text-center text-xs text-white/40">
        {screens[activeScreen].description}
      </p>

      {/* Sticky CTA */}
      <div className="border-t border-white/[0.06] bg-[#0a0a12]/80 p-5 backdrop-blur-xl">
        <PrimaryButton onClick={() => setFlowStep('connect')}>
          Continue to Deploy <ArrowRight size={16} />
        </PrimaryButton>
      </div>
    </div>
  );
}

function PreviewContent({
  screenIndex,
  project,
}: {
  screenIndex: number;
  project: { name: string; color: string; icon: string };
}) {
  if (screenIndex === 0) {
    return (
      <div className="p-4">
        <div className="mb-3 flex items-center justify-between">
          <div>
            <p className="text-[10px] text-white/40">Welcome back</p>
            <p className="text-sm font-bold text-white">{project.name}</p>
          </div>
          <div className={`flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br ${project.color} text-base`}>
            {project.icon}
          </div>
        </div>
        <div className={`mb-3 rounded-2xl bg-gradient-to-br ${project.color} p-3`}>
          <p className="text-[10px] text-white/80">Today's highlight</p>
          <p className="text-sm font-bold text-white">You're on a 7-day streak! 🔥</p>
        </div>
        <div className="grid grid-cols-2 gap-2">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="rounded-xl bg-white/5 p-2.5">
              <div className="mb-1.5 h-12 rounded-lg bg-white/10" />
              <p className="text-[9px] font-medium text-white">Card {i}</p>
              <p className="text-[8px] text-white/40">Lorem ipsum</p>
            </div>
          ))}
        </div>
      </div>
    );
  }
  if (screenIndex === 1) {
    return (
      <div className="p-4">
        <p className="mb-3 text-sm font-bold text-white">Explore</p>
        <div className="mb-3 flex h-8 items-center rounded-lg bg-white/5 px-2">
          <Search size={12} className="text-white/30" />
          <span className="ml-1.5 text-[10px] text-white/30">Search...</span>
        </div>
        {['Featured', 'Trending', 'New'].map((cat, i) => (
          <div key={cat} className="mb-3">
            <p className="mb-1.5 text-[10px] font-semibold text-white/60">{cat}</p>
            <div className="flex gap-2 overflow-hidden">
              {[1, 2].map((j) => (
                <div key={j} className="flex-1 rounded-xl bg-white/5 p-2">
                  <div className={`mb-1.5 h-14 rounded-lg bg-gradient-to-br ${project.color} opacity-${i === 0 ? '100' : '60'}`} />
                  <p className="text-[9px] text-white">Item {j}</p>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    );
  }
  if (screenIndex === 2) {
    return (
      <div className="p-4">
        <p className="mb-3 text-sm font-bold text-white">Activity</p>
        <div className="mb-3 rounded-2xl bg-white/5 p-3">
          <div className="flex items-center justify-between">
            <p className="text-[10px] text-white/50">This week</p>
            <TrendingUp size={12} className="text-emerald-400" />
          </div>
          <p className="text-lg font-bold text-white">+24%</p>
          <div className="mt-2 flex h-16 items-end gap-1">
            {[40, 65, 50, 80, 60, 90, 75].map((h, i) => (
              <div
                key={i}
                className={`flex-1 rounded-t bg-gradient-to-t ${project.color}`}
                style={{ height: `${h}%` }}
              />
            ))}
          </div>
        </div>
        {['Action completed', 'New milestone', 'Goal reached'].map((a, i) => (
          <div key={i} className="mb-2 flex items-center gap-2 rounded-xl bg-white/5 p-2.5">
            <div className={`flex h-7 w-7 items-center justify-center rounded-lg bg-gradient-to-br ${project.color}`}>
              <Star size={12} className="text-white" />
            </div>
            <div className="flex-1">
              <p className="text-[10px] font-medium text-white">{a}</p>
              <p className="text-[8px] text-white/40">{i + 1}h ago</p>
            </div>
          </div>
        ))}
      </div>
    );
  }
  return (
    <div className="p-4">
      <div className="mb-4 flex flex-col items-center">
        <div className={`mb-2 flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br ${project.color} text-2xl`}>
          {project.icon}
        </div>
        <p className="text-sm font-bold text-white">Your Profile</p>
        <p className="text-[10px] text-white/40">Premium Member</p>
      </div>
      {[
        { icon: Heart, label: 'Favorites', val: '24' },
        { icon: ShoppingBag, label: 'Orders', val: '7' },
        { icon: Bell, label: 'Alerts', val: '3' },
        { icon: Star, label: 'Reviews', val: '12' },
      ].map((row) => (
        <div key={row.label} className="mb-2 flex items-center gap-3 rounded-xl bg-white/5 p-2.5">
          <row.icon size={14} className="text-blue-400" />
          <span className="flex-1 text-[10px] text-white">{row.label}</span>
          <span className="text-[10px] font-bold text-white/60">{row.val}</span>
          <ArrowLeft size={10} className="rotate-180 text-white/20" />
        </div>
      ))}
    </div>
  );
}
