import type { ImportedPackage, ImportValidationResult } from './types';

const ACCEPTED_EXTENSIONS = ['apk', 'aab', 'zip'];
const MAX_PACKAGE_BYTES = 150 * 1024 * 1024; // 150 MB

const SAMPLE_PERMISSIONS = [
  'android.permission.INTERNET',
  'android.permission.ACCESS_NETWORK_STATE',
  'android.permission.WAKE_LOCK',
  'android.permission.POST_NOTIFICATIONS',
  'android.permission.READ_EXTERNAL_STORAGE',
  'android.permission.CAMERA',
  'android.permission.VIBRATE',
  'android.permission.FOREGROUND_SERVICE',
];

/**
 * Validates a package file by its name and size.
 * Returns parsed metadata on success or a descriptive error.
 */
export function validatePackage(fileName: string, fileSize: number): ImportValidationResult {
  const ext = fileName.split('.').pop()?.toLowerCase();

  if (!ext || !ACCEPTED_EXTENSIONS.includes(ext)) {
    return {
      ok: false,
      error: `Unsupported file type ".${ext || 'unknown'}". Please upload an APK, AAB, or ZIP file.`,
    };
  }

  if (!fileSize || fileSize === 0) {
    return {
      ok: false,
      error: 'The selected file is empty. Please choose a valid package.',
    };
  }

  if (fileSize > MAX_PACKAGE_BYTES) {
    const mb = (fileSize / (1024 * 1024)).toFixed(1);
    return {
      ok: false,
      error: `File is ${mb} MB — exceeds the 150 MB limit. Please upload a smaller package.`,
    };
  }

  return { ok: true, package: buildPackage(fileName, fileSize, ext as any) };
}

/**
 * Builds plausible, deterministic package metadata from a file name and size.
 */
export function buildPackage(
  fileName: string,
  fileSize: number,
  format: 'apk' | 'aab' | 'zip'
): ImportedPackage {
  const rawBase = fileName.replace(/\.(apk|aab|zip)$/i, '');
  const cleanBase = rawBase.replace(/[-_]+/g, ' ').replace(/\s+/g, ' ').trim() || 'Imported App';
  const appName = cleanBase
    .split(' ')
    .filter(Boolean)
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
    .join(' ');

  const slug = cleanBase.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 14) || 'imported';

  const versionMatch = rawBase.match(/(\d+)\.(\d+)\.(\d+)/);
  const versionName = versionMatch ? versionMatch[0] : '1.0.0';
  const versionCode = versionMatch
    ? parseInt(versionMatch[1]) * 10000 + parseInt(versionMatch[2]) * 100 + parseInt(versionMatch[3])
    : 1;

  const hash = rawBase.split('').reduce((a, c) => a + c.charCodeAt(0), 0);
  const permCount = 3 + (hash % 4);
  const permissions = SAMPLE_PERMISSIONS.slice(0, permCount);

  return {
    fileName,
    fileSize,
    format,
    packageName: `com.quantumforge.${slug}`,
    appName,
    versionName,
    versionCode,
    minSdk: 24 + (hash % 4),
    targetSdk: 34,
    permissions,
    sizeMB: fileSize / (1024 * 1024),
    signature: 'signed',
    architectures: ['arm64-v8a', 'armeabi-v7a', 'x86_64'],
    launchActivity: `com.quantumforge.${slug}.MainActivity`,
  };
}
