// Backend type definitions — independent of frontend types

export interface ProjectFeature {
  icon: string;
  label: string;
}

export interface ProjectScreen {
  name: string;
  description: string;
}

export interface TechItem {
  name: string;
  category: string;
}

export interface Deployment {
  id: string;
  version: string;
  platform: 'android' | 'ios' | 'web';
  status: 'live' | 'in_review' | 'draft' | 'failed';
  date: string;
  downloads?: number;
}

export interface Project {
  id: string;
  name: string;
  tagline: string;
  description: string;
  category: string;
  color: string;
  icon: string;
  features: ProjectFeature[];
  screens: ProjectScreen[];
  techStack: TechItem[];
  repo: string;
  lastDeployed: string;
  status: 'live' | 'in_review' | 'draft';
  version: string;
  deployments: Deployment[];
  downloads: number;
  rating: number;
}

export interface ConnectedAccount {
  id: string;
  name: string;
  handle: string;
  platform: 'github' | 'googleplay';
  connected: boolean;
}

export interface User {
  id: string;
  name: string;
  email: string;
  plan: string;
}

export interface ImportedPackage {
  fileName: string;
  fileSize: number;
  format: 'apk' | 'aab' | 'zip';
  packageName: string;
  appName: string;
  versionName: string;
  versionCode: number;
  minSdk: number;
  targetSdk: number;
  permissions: string[];
  sizeMB: number;
  signature: 'signed' | 'unsigned' | 'debug';
  architectures: string[];
  launchActivity: string;
}

export interface ImportValidationResult {
  ok: boolean;
  error?: string;
  package?: ImportedPackage;
}

export interface DeployTask {
  id: string;
  label: string;
  detail: string;
  status: 'pending' | 'active' | 'done' | 'error';
}

export interface DeploymentRecord {
  id: string;
  projectId: string;
  mode: 'generate' | 'import';
  startTime: number;
  stepDuration: number;
  tasks: DeployTask[];
  project: Project;
}

export interface Stats {
  liveApps: number;
  totalDownloads: number;
  avgRating: number;
  totalProjects: number;
}

export interface ApiResponse<T> {
  data?: T;
  error?: string;
  token?: string;
}
