import { verifyToken, createToken } from './db';

/** Extract user ID from the Authorization header. Returns null if unauthenticated. */
export function getUserIdFromRequest(req: any): string | null {
  const auth = req.headers?.authorization || req.headers?.Authorization;
  if (!auth || typeof auth !== 'string') return null;
  if (!auth.startsWith('Bearer ')) return null;
  const token = auth.slice(7);
  return verifyToken(token);
}

/** Ensure a user is authenticated. If not, auto-create a demo token for convenience. */
export function ensureAuth(req: any): { userId: string; token: string | null } {
  const existing = getUserIdFromRequest(req);
  if (existing) {
    return { userId: existing, token: null };
  }
  // Auto-login as demo user for seamless API access
  const token = createToken('demo-user');
  return { userId: 'demo-user', token };
}
