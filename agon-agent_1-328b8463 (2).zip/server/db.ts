import type {
  Project,
  ConnectedAccount,
  User,
  Stats,
  DeploymentRecord,
} from './types';

declare global {
  // eslint-disable-next-line no-var
  var __qf_db: DatabaseState | undefined;
}

interface DatabaseState {
  projects: Project[];
  accounts: ConnectedAccount[];
  users: User[];
  tokens: Map<string, string>;
  deployments: Map<string, DeploymentRecord>;
}

const seedProjects: Project[] = [
  {
    id: 'p1',
    name: 'FitFlow',
    tagline: 'AI workout companion',
    description:
      'A modern fitness tracking app with AI-generated workout plans, progress analytics, and social challenges.',
    category: 'Health & Fitness',
    color: 'from-emerald-500 to-teal-600',
    icon: '💪',
    features: [
      { icon: 'dumbbell', label: 'Workout Plans' },
      { icon: 'trending-up', label: 'Progress Tracking' },
      { icon: 'users', label: 'Social Challenges' },
      { icon: 'bell', label: 'Smart Reminders' },
    ],
    screens: [
      { name: 'Dashboard', description: 'Daily stats & activity rings' },
      { name: 'Workouts', description: 'Browse & start training sessions' },
      { name: 'Progress', description: 'Charts & achievement history' },
      { name: 'Profile', description: 'Goals & preferences' },
    ],
    techStack: [
      { name: 'React Native', category: 'Framework' },
      { name: 'Expo', category: 'Platform' },
      { name: 'Firebase', category: 'Backend' },
      { name: 'TypeScript', category: 'Language' },
    ],
    repo: 'alexchen/fitflow',
    lastDeployed: '2 days ago',
    status: 'live',
    version: 'v1.2.0',
    downloads: 18420,
    rating: 4.7,
    deployments: [
      { id: 'd1', version: 'v1.2.0', platform: 'android', status: 'live', date: '2 days ago', downloads: 18420 },
      { id: 'd2', version: 'v1.1.0', platform: 'android', status: 'live', date: '2 weeks ago', downloads: 12100 },
      { id: 'd3', version: 'v1.0.0', platform: 'android', status: 'live', date: '1 month ago', downloads: 8200 },
    ],
  },
  {
    id: 'p2',
    name: 'MealMuse',
    tagline: 'Your AI sous chef',
    description:
      'Discover recipes based on ingredients you have, plan meals for the week, and generate smart shopping lists.',
    category: 'Food & Drink',
    color: 'from-orange-500 to-rose-600',
    icon: '🍳',
    features: [
      { icon: 'search', label: 'Recipe Search' },
      { icon: 'calendar', label: 'Meal Planning' },
      { icon: 'shopping-cart', label: 'Shopping Lists' },
      { icon: 'heart', label: 'Favorites' },
    ],
    screens: [
      { name: 'Discover', description: 'Trending & suggested recipes' },
      { name: 'Recipe Detail', description: 'Steps, ingredients & timer' },
      { name: 'Meal Plan', description: 'Weekly calendar view' },
      { name: 'Pantry', description: 'Track ingredients on hand' },
    ],
    techStack: [
      { name: 'Flutter', category: 'Framework' },
      { name: 'Supabase', category: 'Backend' },
      { name: 'Dart', category: 'Language' },
      { name: 'OpenAI API', category: 'AI' },
    ],
    repo: 'alexchen/mealmuse',
    lastDeployed: '5 days ago',
    status: 'in_review',
    version: 'v0.9.1',
    downloads: 3200,
    rating: 4.5,
    deployments: [
      { id: 'd4', version: 'v0.9.1', platform: 'android', status: 'in_review', date: '5 days ago' },
      { id: 'd5', version: 'v0.8.0', platform: 'android', status: 'live', date: '3 weeks ago', downloads: 3200 },
    ],
  },
  {
    id: 'p3',
    name: 'TaskTide',
    tagline: 'Tasks that flow with you',
    description:
      'A minimalist task manager with natural language input, smart prioritization, and focus mode.',
    category: 'Productivity',
    color: 'from-violet-500 to-indigo-600',
    icon: '✅',
    features: [
      { icon: 'check-square', label: 'Smart Tasks' },
      { icon: 'zap', label: 'Quick Capture' },
      { icon: 'target', label: 'Focus Mode' },
      { icon: 'bar-chart', label: 'Productivity Stats' },
    ],
    screens: [
      { name: 'Today', description: "Today's tasks & priorities" },
      { name: 'Projects', description: 'Organize tasks by project' },
      { name: 'Focus', description: 'Pomodoro timer & deep work' },
      { name: 'Insights', description: 'Weekly productivity trends' },
    ],
    techStack: [
      { name: 'React Native', category: 'Framework' },
      { name: 'WatermelonDB', category: 'Database' },
      { name: 'TypeScript', category: 'Language' },
      { name: 'OpenAI API', category: 'AI' },
    ],
    repo: 'alexchen/tasktide',
    lastDeployed: '3 weeks ago',
    status: 'live',
    version: 'v2.0.1',
    downloads: 9800,
    rating: 4.8,
    deployments: [
      { id: 'd6', version: 'v2.0.1', platform: 'android', status: 'live', date: '3 weeks ago', downloads: 9800 },
      { id: 'd7', version: 'v1.5.0', platform: 'android', status: 'live', date: '2 months ago', downloads: 6400 },
    ],
  },
  {
    id: 'p4',
    name: 'Wanderly',
    tagline: 'Plan trips with AI',
    description:
      'Generate personalized travel itineraries, discover hidden gems, and book experiences on the go.',
    category: 'Travel',
    color: 'from-sky-500 to-blue-600',
    icon: '✈️',
    features: [
      { icon: 'map', label: 'AI Itineraries' },
      { icon: 'compass', label: 'Discover Places' },
      { icon: 'bookmark', label: 'Saved Trips' },
      { icon: 'share-2', label: 'Share Plans' },
    ],
    screens: [
      { name: 'Explore', description: 'Destination inspiration' },
      { name: 'Itinerary', description: 'Day-by-day trip plan' },
      { name: 'Map View', description: 'Interactive trip map' },
      { name: 'Trips', description: 'Past & upcoming journeys' },
    ],
    techStack: [
      { name: 'React Native', category: 'Framework' },
      { name: 'Firebase', category: 'Backend' },
      { name: 'Mapbox', category: 'Maps' },
      { name: 'TypeScript', category: 'Language' },
    ],
    repo: 'alexchen/wanderly',
    lastDeployed: '1 month ago',
    status: 'draft',
    version: 'v0.5.0',
    downloads: 0,
    rating: 0,
    deployments: [
      { id: 'd8', version: 'v0.5.0', platform: 'android', status: 'draft', date: '1 month ago' },
    ],
  },
];

const seedAccounts: ConnectedAccount[] = [
  { id: 'gh', name: 'GitHub', handle: '@alexchen', platform: 'github', connected: true },
  { id: 'gp', name: 'Google Play', handle: 'Alex Chen Dev', platform: 'googleplay', connected: false },
];

const seedUsers: User[] = [
  { id: 'demo-user', name: 'Alex Chen', email: 'alex@quantumforge.ai', plan: 'Pro' },
];

function createDb(): DatabaseState {
  return {
    projects: [...seedProjects],
    accounts: [...seedAccounts],
    users: [...seedUsers],
    tokens: new Map(),
    deployments: new Map(),
  };
}

export function getDb(): DatabaseState {
  if (!globalThis.__qf_db) {
    globalThis.__qf_db = createDb();  }
  return globalThis.__qf_db;
}

export function getProjects(): Project[] {
  return getDb().projects;
}

export function getProject(id: string): Project | undefined {
  return getDb().projects.find((p) => p.id === id);
}

export function addProject(project: Project): Project {
  getDb().projects.unshift(project);
  return project;
}

export function updateProject(id: string, data: Partial<Project>): Project | undefined {
  const db = getDb();
  const idx = db.projects.findIndex((p) => p.id === id);
  if (idx === -1) return undefined;
  db.projects[idx] = { ...db.projects[idx], ...data };
  return db.projects[idx];
}

export function deleteProject(id: string): boolean {
  const db = getDb();
  const idx = db.projects.findIndex((p) => p.id === id);
  if (idx === -1) return false;
  db.projects.splice(idx, 1);
  return true;
}

export function getAccounts(): ConnectedAccount[] {
  return getDb().accounts;
}

export function toggleAccount(platform: string): ConnectedAccount | undefined {
  const db = getDb();
  const account = db.accounts.find((a) => a.platform === platform || a.id === platform);
  if (!account) return undefined;
  account.connected = !account.connected;
  return account;
}

export function getStats(): Stats {
  const projects = getDb().projects;
  const liveApps = projects.filter((p) => p.status === 'live').length;
  const totalDownloads = projects.reduce((s, p) => s + p.downloads, 0);
  const ratedProjects = projects.filter((p) => p.rating > 0);
  const avgRating = ratedProjects.length > 0
    ? ratedProjects.reduce((s, p) => s + p.rating, 0) / ratedProjects.length
    : 0;
  return {
    liveApps,
    totalDownloads,
    avgRating: parseFloat(avgRating.toFixed(1)),
    totalProjects: projects.length,
  };
}

export function getUser(id: string): User | undefined {
  return getDb().users.find((u) => u.id === id);
}

export function findUserByEmail(email: string): User | undefined {
  return getDb().users.find((u) => u.email.toLowerCase() === email.toLowerCase());
}

export function createToken(userId: string): string {
  const token = `qf_${Buffer.from(`${userId}:${Date.now()}`).toString('base64')}`;
  getDb().tokens.set(token, userId);
  return token;
}

export function verifyToken(token: string): string | null {
  return getDb().tokens.get(token) || null;
}

export function saveDeployment(record: DeploymentRecord): void {
  getDb().deployments.set(record.id, record);
}

export function getDeployment(id: string): DeploymentRecord | undefined {
  return getDb().deployments.get(id);
}
