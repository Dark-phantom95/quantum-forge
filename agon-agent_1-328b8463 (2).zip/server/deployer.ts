import type { DeploymentRecord, DeployTask, Project } from './types';
import { saveDeployment, getDeployment } from './db';

const STEP_DURATION = 1700; // ms per step — matches frontend timing

const generateDeployTasks: DeployTask[] = [
  { id: 'build', label: 'Compiling build', detail: 'Bundling production assets', status: 'pending' },
  { id: 'repo', label: 'Syncing repository', detail: 'Pushing to GitHub', status: 'pending' },
  { id: 'version', label: 'Creating release', detail: 'Tagging version v1.0.0', status: 'pending' },
  { id: 'store', label: 'Submitting to Play Store', detail: 'Uploading AAB to Google Play', status: 'pending' },
  { id: 'live', label: 'Going live', detail: 'Activating production release', status: 'pending' },
];

const importDeployTasks: DeployTask[] = [
  { id: 'validate', label: 'Validating package', detail: 'Re-checking signed bundle integrity', status: 'pending' },
  { id: 'repo', label: 'Syncing repository', detail: 'Pushing source to GitHub', status: 'pending' },
  { id: 'version', label: 'Creating release', detail: 'Tagging version from manifest', status: 'pending' },
  { id: 'store', label: 'Submitting to Play Store', detail: 'Uploading bundle to Google Play', status: 'pending' },
  { id: 'live', label: 'Going live', detail: 'Activating production release', status: 'pending' },
];

/** Creates and stores a new deployment record. */
export function startDeployment(
  project: Project,
  mode: 'generate' | 'import'
): DeploymentRecord {
  const baseTasks = mode === 'import' ? importDeployTasks : generateDeployTasks;
  const tasks: DeployTask[] = baseTasks.map((t) => ({ ...t, status: 'pending' as const }));

  const record: DeploymentRecord = {
    id: `dep_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    projectId: project.id,
    mode,
    startTime: Date.now(),
    stepDuration: STEP_DURATION,
    tasks,
    project,
  };

  saveDeployment(record);
  return record;
}

/**
 * Computes deployment status based on elapsed time since start.
 * Each step takes `stepDuration` ms. This is stateless and works
 * reliably across serverless invocations.
 */
export function getDeploymentStatus(id: string): {
  tasks: DeployTask[];
  progress: number;
  complete: boolean;
  project?: Project;
} | null {
  const record = getDeployment(id);
  if (!record) return null;

  const elapsed = Date.now() - record.startTime;
  const completedSteps = Math.min(
    Math.floor(elapsed / record.stepDuration),
    record.tasks.length
  );

  const tasks: DeployTask[] = record.tasks.map((task, i) => {
    if (i < completedSteps) return { ...task, status: 'done' as const };
    if (i === completedSteps && completedSteps < record.tasks.length) {
      return { ...task, status: 'active' as const };
    }
    return { ...task, status: 'pending' as const };
  });

  const doneCount = tasks.filter((t) => t.status === 'done').length;
  const progress = (doneCount / tasks.length) * 100;
  const complete = doneCount === tasks.length;

  return { tasks, progress, complete, project: record.project };
}
