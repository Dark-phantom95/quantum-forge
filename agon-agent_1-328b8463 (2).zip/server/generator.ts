import type { Project } from './types';

/**
 * Generates a complete project from a natural-language idea.
 * This is the server-side equivalent of the frontend generator.
 */
export function generateProjectFromIdea(idea: string): Project {
  const lower = idea.toLowerCase();
  let name = 'Nimbus';
  let tagline = 'AI-powered app';
  let category = 'Productivity';
  let color = 'from-blue-500 to-violet-600';
  let icon = '🚀';

  if (lower.includes('shop') || lower.includes('store') || lower.includes('commerce') || lower.includes('cart')) {
    name = 'ShopSphere';
    tagline = 'Your store, reinvented';
    category = 'Shopping';
    color = 'from-fuchsia-500 to-purple-600';
    icon = '🛍️';
  } else if (lower.includes('fit') || lower.includes('workout') || lower.includes('exercise') || lower.includes('gym')) {
    name = 'PulseFit';
    tagline = 'Train smarter, not harder';
    category = 'Health & Fitness';
    color = 'from-emerald-500 to-teal-600';
    icon = '💪';
  } else if (lower.includes('recipe') || lower.includes('food') || lower.includes('cook') || lower.includes('meal')) {
    name = 'Savorly';
    tagline = 'Cook with inspiration';
    category = 'Food & Drink';
    color = 'from-orange-500 to-rose-600';
    icon = '🍳';
  } else if (lower.includes('budget') || lower.includes('finance') || lower.includes('money') || lower.includes('expense')) {
    name = 'CoinWise';
    tagline = 'Master your money';
    category = 'Finance';
    color = 'from-amber-500 to-yellow-600';
    icon = '💰';
  } else if (lower.includes('travel') || lower.includes('trip') || lower.includes('journey')) {
    name = 'Voyagr';
    tagline = 'Adventure awaits';
    category = 'Travel';
    color = 'from-sky-500 to-cyan-600';
    icon = '✈️';
  } else if (lower.includes('meditat') || lower.includes('mindful') || lower.includes('calm') || lower.includes('wellness')) {
    name = 'ZenFlow';
    tagline = 'Find your inner peace';
    category = 'Health & Fitness';
    color = 'from-teal-500 to-cyan-600';
    icon = '🧘';
  } else if (lower.includes('social') || lower.includes('chat') || lower.includes('message') || lower.includes('connect')) {
    name = 'PulseChat';
    tagline = 'Connect with everyone';
    category = 'Social';
    color = 'from-pink-500 to-rose-600';
    icon = '💬';
  } else if (lower.includes('game') || lower.includes('play') || lower.includes('fun')) {
    name = 'PlayForge';
    tagline = 'Game on';
    category = 'Games';
    color = 'from-purple-500 to-indigo-600';
    icon = '🎮';
  }

  return {
    id: `gen_${Date.now()}`,
    name,
    tagline,
    description: idea.trim(),
    category,
    color,
    icon,
    features: [
      { icon: 'zap', label: 'Smart Automation' },
      { icon: 'bell', label: 'Push Notifications' },
      { icon: 'shield', label: 'Secure Auth' },
      { icon: 'bar-chart', label: 'Analytics Dashboard' },
    ],
    screens: [
      { name: 'Home', description: 'Personalized dashboard & feed' },
      { name: 'Explore', description: 'Browse & discover content' },
      { name: 'Activity', description: 'Recent actions & history' },
      { name: 'Profile', description: 'Account & settings' },
    ],
    techStack: [
      { name: 'React Native', category: 'Framework' },
      { name: 'Expo', category: 'Platform' },
      { name: 'Firebase', category: 'Backend' },
      { name: 'TypeScript', category: 'Language' },
    ],
    repo: '',
    lastDeployed: 'Not deployed',
    status: 'draft',
    version: 'v1.0.0',
    downloads: 0,
    rating: 0,
    deployments: [],
  };
}

/** Maps an imported package into a Project for the deploy flow. */
export function generateProjectFromPackage(pkg: {
  appName: string;
  packageName: string;
  versionName: string;
  versionCode: number;
  fileName: string;
  format: string;
  minSdk: number;
  targetSdk: number;
  permissions: string[];
  launchActivity: string;
}): Project {
  const formatLabel = pkg.format.toUpperCase();
  return {
    id: `imp_${Date.now()}`,
    name: pkg.appName,
    tagline: `Imported ${formatLabel} package`,
    description: `Imported from ${pkg.fileName}. Package ${pkg.packageName}, version ${pkg.versionName} (code ${pkg.versionCode}). Validated and ready for store deployment.`,
    category: 'Imported App',
    color: 'from-blue-500 to-violet-600',
    icon: '📦',
    features: [
      { icon: 'package', label: `${formatLabel} Package` },
      { icon: 'shield', label: 'Signature Verified' },
      { icon: 'cpu', label: `API ${pkg.minSdk}+ Compatible` },
      { icon: 'lock', label: `${pkg.permissions.length} Permissions` },
    ],
    screens: [
      { name: 'Main Activity', description: pkg.launchActivity },
      { name: 'Splash', description: 'Cold-start splash screen' },
      { name: 'Settings', description: 'App preferences' },
      { name: 'About', description: 'Version & build info' },
    ],
    techStack: [
      { name: 'Android', category: 'Platform' },
      { name: `minSdk ${pkg.minSdk}`, category: 'API Level' },
      { name: `targetSdk ${pkg.targetSdk}`, category: 'API Level' },
      { name: formatLabel, category: 'Format' },
    ],
    repo: '',
    lastDeployed: 'Not deployed',
    status: 'draft',
    version: `v${pkg.versionName}`,
    downloads: 0,
    rating: 0,
    deployments: [],
  };
}
